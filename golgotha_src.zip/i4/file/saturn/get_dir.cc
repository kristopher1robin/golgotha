/********************************************************************** <BR>
  This file is part of Crack dot Com's free source code release of
  Golgotha. <a href="http://www.crack.com/golgotha_release"> <BR> for
  information about compiling & licensing issues visit this URL</a> 
  <PRE> If that doesn't help, contact Jonathan Clark at 
  golgotha_source@usa.net (Subject should have "GOLG" in it) 
***********************************************************************/

#include "file/get_dir.hh"

i4_bool i4_get_directory(const i4_const_str &path, 
                      i4_str **&files, w32 &tfiles,
                      i4_str **&dirs, w32 &tdirs)
{
  tfiles=0;
  tdirs=0;
}
