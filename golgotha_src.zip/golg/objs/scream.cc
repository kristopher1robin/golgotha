/********************************************************************** <BR>
  This file is part of Crack dot Com's free source code release of
  Golgotha. <a href="http://www.crack.com/golgotha_release"> <BR> for
  information about compiling & licensing issues visit this URL</a> 
  <PRE> If that doesn't help, contact Jonathan Clark at 
  golgotha_source@usa.net (Subject should have "GOLG" in it) 
***********************************************************************/

#include "objs/scream.hh"
#include "sfx_id.hh"
#include "sound_man.hh"
#include "math/random.hh"



void g1_play_scream(i4_float x, i4_float y, i4_float h, g1_scream_type type)
{
  //  g1_sound_man.play_3d(g1_scream_ids[/*i4_rand() % 4*/0], x,y,h);
}
