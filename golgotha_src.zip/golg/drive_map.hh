/********************************************************************** <BR>
  This file is part of Crack dot Com's free source code release of
  Golgotha. <a href="http://www.crack.com/golgotha_release"> <BR> for
  information about compiling & licensing issues visit this URL</a> 
  <PRE> If that doesn't help, contact Jonathan Clark at 
  golgotha_source@usa.net (Subject should have "GOLG" in it) 
***********************************************************************/

#ifndef DRIVE_MAP_HH
#define DRIVE_MAP_HH

#error "this file is not needed anymore"
void g1_map_drives();    // does drive mapping used by golgotha (c: -> /tmp f: /u, etc)
void g1_unmap_drives();

#endif


