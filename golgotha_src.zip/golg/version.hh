/********************************************************************** <BR>
  This file is part of Crack dot Com's free source code release of
  Golgotha. <a href="http://www.crack.com/golgotha_release"> <BR> for
  information about compiling & licensing issues visit this URL</a> 
  <PRE> If that doesn't help, contact Jonathan Clark at 
  golgotha_source@usa.net (Subject should have "GOLG" in it) 
***********************************************************************/

#ifndef G1_VERSION_HH
#define G1_VERSION_HH

// if you want to use the wad-file file system instead of the
// normal uncomment below and make sure to run ../cd_maker/cd_maker

//#define G1_RETAIL


#endif
