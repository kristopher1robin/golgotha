/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

#include "device/event.hh"
#include "video/display.hh"
#include "device/device.hh"


#include "image/image.hh"
#include "quantize/histogram.hh"
#include "quantize/median.hh"
#include "loaders/tga_write.hh"
#include "video/display.hh"
#include "palette/pal.hh"
#include "device/kernel.hh"
#include "loaders/tga_write.hh"
#include "app/app.hh"
#include "device/keys.hh"

class g1_screen_shot_watcher_class : public i4_event_handler_class
{  
  int num_shots;
  w16 key;

public:
  g1_screen_shot_watcher_class()
  {
    key=I4_F2;
    
    i4_kernel.request_events(this, i4_device_class::FLAG_KEY_PRESS);
    num_shots = 0;
  }

  ~g1_screen_shot_watcher_class()
  {
    i4_kernel.unrequest_events(this, i4_device_class::FLAG_KEY_PRESS);
  }

  void save_shot()
  {
    i4_display_class *display=i4_current_app->get_display();
    if (display)
    {      
      char outname[200];
      sprintf(outname, "shot%03d.tga", num_shots++);
    
      i4_file_class *fp=i4_open(outname, I4_WRITE);
      i4_image_class *screen=display->lock_frame_buffer(I4_BACK_FRAME_BUFFER, I4_FRAME_BUFFER_READ);
      if (screen)
      {
        i4_tga_write(screen, fp);
        display->unlock_frame_buffer(I4_BACK_FRAME_BUFFER);
      }
 
      delete fp;
    }
  }

  void receive_event(i4_event *ev)
  {
    if (ev->type()==i4_event::KEY_PRESS)
    {
      CAST_PTR(kev, i4_key_press_event_class, ev);
      if (kev->key == key)
        save_shot();
    }
  }

  char *name() { return "screen_shot watcher"; }
};

static g1_screen_shot_watcher_class *g1_screen_shot_instance=0;

class g1_screen_shot_adder : public i4_init_class
{
public:
  void init() { g1_screen_shot_instance=new g1_screen_shot_watcher_class(); }
  void uninit() { delete g1_screen_shot_instance; g1_screen_shot_instance=0; }
} g1_screen_shot_adder_instance;


