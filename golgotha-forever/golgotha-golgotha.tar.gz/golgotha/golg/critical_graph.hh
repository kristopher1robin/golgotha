/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

#error

#ifndef CRITICAL_GRAPH_HH
#define CRITICAL_GRAPH_HH

#include "g1_limits.hh"
#include "math/num_type.hh"
#include "saver.hh"

typedef w8 g1_graph_node;

class g1_critical_graph_class
{
  friend class g1_critical_map_maker_class;
public:
  enum { MAX_CRITICALS=256, MAX_CONNECTIONS=100 };

  class connection_class
  {
  public:
    g1_graph_node ref;
    i4_float dist;
    w8 size[G1_GRADE_LEVELS];
  };

  class critical_point_class
  {
  public:
    i4_float x,y; 
    connection_class *connection;
    w8 connections;
    w8 selected;
  };

protected:
  connection_class *pool;
  w32 pool_connections;
public:
  critical_point_class critical[MAX_CRITICALS];
  // note critical point 0 is used to mark the null 

  w16 criticals;

  g1_critical_graph_class() : criticals(1), pool(0) {}
  g1_critical_graph_class(g1_loader_class *f) : pool(0) { load_points(f); }
  ~g1_critical_graph_class();

  void clear_critical_graph();
  void compact_critical_graph();
  void expand_critical_graph();

  i4_bool add_critical_point(float x, float y);

  void save_points(g1_saver_class *f);
  void save_graph(g1_saver_class *f);
  void load_points(g1_loader_class *f);
  void load_graph(g1_loader_class *f);
};

#endif

//{{{ Emacs Locals
// Local Variables:
// folded-file: t
// End:
//}}}

