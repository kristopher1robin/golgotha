/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

#ifndef G1_TINT_HH
#define G1_TINT_HH

// this is in a seperate file so maxtool and golgotha can share this code

#include "g1_limits.hh"
#include "r1_api.hh"

enum { G1_NUM_HURT_TINTS = 5 };
enum g1_tint_type { G1_TINT_OFF, G1_TINT_POLYS, G1_TINT_ALL };

extern g1_tint_type g1_tint;
extern r1_color_tint_handle g1_player_tint_handles[G1_MAX_PLAYERS];
extern r1_color_tint_handle g1_hurt_tint_handles[G1_NUM_HURT_TINTS];

extern int g1_hurt_tint;


struct g1_tint_struct { i4_float r,g,b; };
extern g1_tint_struct g1_player_tint_data[G1_MAX_PLAYERS];
extern g1_tint_struct g1_hurt_tint_data[G1_NUM_HURT_TINTS];

// this will register the color tints with the rendering api, afterwards you can call
// api->set_color_tint(player_tint_handles[player_num]);
void g1_init_color_tints(r1_render_api_class *api);



#endif
