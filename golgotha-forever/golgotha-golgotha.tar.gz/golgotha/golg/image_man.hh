/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

#ifndef G1_IMAGE_MAN_HH
#define G1_IMAGE_MAN_HH

#include "g1_limits.hh"

class i4_image_class;

struct g1_image_ref
{
  static g1_image_ref *first;
  g1_image_ref *next;
  const char *image_name;
  i4_image_class *im;

  virtual void cleanup();
  virtual void load();

  g1_image_ref(const char *filename);
  virtual ~g1_image_ref();

  // this will delete the old image (if present)
  // and load up a new one
  void set_image(const char *filename);  
  i4_image_class *get() { return im; }
};

struct g1_team_icon_ref : public g1_image_ref
{
  virtual void load();

  i4_image_class *tinted_icons[G1_MAX_PLAYERS];
  g1_team_icon_ref(const char *filename);
  virtual void cleanup();
  virtual ~g1_team_icon_ref() {};
};


void g1_load_images();
void g1_unload_images();

#endif
