/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

#ifndef G1_SPRITE_HH
#define G1_SPRITE_HH

#include "g1_limits.hh"
#include "tex_id.hh"

class r1_render_api_class;

class g1_sprite_class
{
public:
  i4_float texture_scale;
  i4_float add_x, add_y;     // added to sprites position before transform
                             // these numbers are calculated from vertex[0] of the quadgon 
                             // loaded from 3d studio model
  r1_texture_handle texture;
  sw32 num_animation_frames;
  i4_float extent;
} ;

class g1_sprite_list_class
{
  g1_sprite_class array[G1_MAX_SPRITES];

public:
  void load(r1_render_api_class *tmap);
  g1_sprite_class *get_sprite(w16 handle) { return &array[handle]; }
} ;

extern g1_sprite_list_class g1_sprite_list_man;

#endif
