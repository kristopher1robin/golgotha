/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

#ifndef G1_BOLT_HH
#define G1_BOLT_HH

#include "objs/map_piece.hh"

class g1_bolt_class : public g1_object_class
{
public:
  int ticks;
  i4_bool first, lit;
  i4_3d_vector target_pos;
  i4_float w1,w2;
  i4_color c1,c2;
  i4_float a1,a2;
  i4_float size;
  s1_sound_handle sfx_loop;

  g1_typed_reference_class<g1_object_class> originator;
  g1_typed_reference_class<g1_object_class> target;
  g1_typed_reference_class<g1_light_object_class> light, end_light;
  
  enum {NUM_ARCS=5};
  
  struct arc_point
  {
    i4_3d_vector lposition,position;
  } arc[NUM_ARCS];

  void request_remove();

  void setup(const i4_3d_vector &start_pos,
             const i4_3d_vector &target_pos,
             g1_object_class *originator,
             g1_object_class *target=0);

  void setup_look(i4_float _size,
                  i4_float start_width,     i4_float end_width,
                  i4_color start_color,     i4_color end_color,
                  i4_float start_alpha=1.0, i4_float end_alpha=1.0,
                  i4_bool  _lit=i4_F)
  {
    size = _size;
    w1 = start_width; w2 = end_width;
    c1 = start_color; c2 = end_color;
    a1 = start_alpha; a2 = end_alpha;
    lit = _lit;
  }

  void move(const i4_3d_vector &pos);
  void arc_to(const i4_3d_vector &target);
  void copy_old_points();

  ~g1_bolt_class();

  g1_bolt_class(g1_object_type id, g1_loader_class *fp);
  virtual void save(g1_saver_class *fp);
  virtual void draw(g1_draw_context_class *context);  
  virtual void think();
  virtual void post_think();

  void create_light();
  void destroy_light();
};

#endif
