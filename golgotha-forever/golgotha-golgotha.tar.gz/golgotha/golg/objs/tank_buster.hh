/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

#ifndef G1_TANK_BUSTER_HH
#define G1_TANK_BUSTER_HH

#include "objs/map_piece.hh"
#include "objs/stank.hh"
#include "objs/buster_rocket.hh"
#include "resources.hh"

class g1_tank_buster_class : public g1_map_piece_class
{
protected:
  w8 rack_state;
  sw8 explode_delay;

  g1_mini_object *missile;

public:
  
  g1_tank_buster_class(g1_object_type id, g1_loader_class *fp);
  void save(g1_saver_class *fp);

  i4_bool can_attack(g1_object_class *who) const
  {
    g1_player_piece_class *o = g1_player_piece_class::cast(who);
    
    //not a supertank? cant attack it
    if (!o) return i4_F;

    return g1_map_piece_class::can_attack(who);
  }

  virtual void fire();
  virtual void think();

  void raise_missile();
  void lower_missile();
};

#endif
