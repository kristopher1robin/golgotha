/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

#ifndef G1_VEHIC_SOUNDS_HH
#define G1_VEHIC_SOUNDS_HH

#include "math/vector.hh"

enum g1_rumble_type
{
  G1_RUMBLE_GROUND,
  G1_RUMBLE_HELI,
  G1_RUMBLE_JET,
  G1_RUMBLE_MISSILE,
  G1_RUMBLE_STANK,
  G1_T_RUMBLES 
};



void g1_add_to_sound_average(g1_rumble_type type, 
                             const i4_3d_vector& pos, const i4_3d_vector& vel);
             
void g1_add_to_sound_average(g1_rumble_type type, const i4_3d_vector& pos);

void g1_reset_sound_averages();
void g1_recalc_sound_averages();
void g1_stop_sound_averages();

#endif
