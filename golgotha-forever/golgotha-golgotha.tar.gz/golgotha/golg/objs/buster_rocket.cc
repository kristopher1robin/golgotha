/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

#include "g1_object.hh"
#include "math/num_type.hh"
#include "math/angle.hh"
#include "math/trig.hh"
#include "math/random.hh"
#include "tile.hh"
#include "saver.hh"
#include "math/pi.hh"
#include "map.hh"
#include "map_man.hh"
#include "object_definer.hh"
#include "resources.hh"

#include "objs/buster_rocket.hh"
#include "objs/map_piece.hh"
#include "objs/smoke_trail.hh"
#include "objs/stank.hh"
#include "objs/particle_emitter.hh"
#include "lisp/lisp.hh"
#include "li_objref.hh"

static li_symbol_ref li_particle_emitter("particle_emitter");
static li_g1_ref_class_member smoke_trail("smoke_trail");

enum { DATA_VERSION=2 };

g1_object_definer<g1_buster_rocket_class>
g1_buster_rocket_def("buster_rocket");

g1_object_definer<g1_buster_rocket_class>
g1_heavy_rocket_def("heavy_rocket");

g1_object_definer<g1_buster_rocket_class>
g1_vortex_def("vortex_missile");

g1_object_definer<g1_buster_rocket_class>
g1_nuke_def("nuke_missile");


g1_buster_rocket_class::g1_buster_rocket_class(g1_object_type id,
                                               g1_loader_class *fp)
  : g1_guided_missile_class(id,fp)
{
}

static r1_texture_ref smoke_ref("smoke_particle");

void g1_buster_rocket_class::add_smoke()
{
  g1_particle_emitter_params p;
  g1_particle_emitter_class *emitter;
  p.defaults();
  p.start_size=0.05;
  p.grow_speed=0.01;
  p.max_speed=0.02;
  p.air_friction=0.80;
  p.num_create_attempts_per_tick=1;
  p.particle_lifetime=20;
  
  p.texture=smoke_ref.get();

  emitter = (g1_particle_emitter_class *)
    g1_create_object(g1_get_object_type(li_particle_emitter.get()));
  emitter->setup(x,y,h, p);
  
  vars->set(smoke_trail, new li_g1_ref(emitter));
}

void g1_buster_rocket_class::update_smoke()
{
  li_class_context c(vars);

  if (!smoke_trail())
    return;

  g1_particle_emitter_class *st=(g1_particle_emitter_class *) smoke_trail()->value();
  if (st)
    st->move(lx,ly,lh);
}

void g1_buster_rocket_class::delete_smoke()
{
  li_class_context c(vars);

  if (!smoke_trail())
    return;

  g1_particle_emitter_class *st=(g1_particle_emitter_class *) smoke_trail()->value();
  if (st)
  {
    st->unoccupy_location();
    st->request_remove();
    vars->set(smoke_trail, li_g1_null_ref());
  }
}


