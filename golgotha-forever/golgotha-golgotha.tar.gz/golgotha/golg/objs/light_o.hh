/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

#ifndef G1_LIGHT_OBJECT_HH
#define G1_LIGHT_OBJECT_HH

#include "g1_object.hh"
#include "g1_render.hh"
#include "objs/model_draw.hh"

extern g1_object_type g1_lightbulb_type;


class g1_light_object_class : public g1_object_class
{
public:
  static g1_light_object_class *cast(g1_object_class *obj)
  {
    if (!obj || obj->id != g1_lightbulb_type)
    { 
#ifdef I4_CAST_WARN
      i4_warning("bad cast to lightbulb_obj!\n"); 
#endif
      return 0; 
    }
    
    return (g1_light_object_class *)obj;
  }

  i4_float r,g,b;                      // 0..1 if colored lighting supported
  i4_float white;                      // 0..1 if only white light supported

  // light atenuation formula = min(1/(c1 + c2*d + c3*d*d),1)
  i4_float c1,c2,c3;                   // 0..1 light antenuation values

  g1_light_object_class *next;   // next point source light in list

  sw32 change_radius;
  w32 *add_intensities;


  enum { DATA_VERSION=0 };

  g1_light_object_class(g1_object_type id, g1_loader_class *fp);

  void save(g1_saver_class *fp);

  virtual i4_bool occupy_location();
  virtual void unoccupy_location();
  
  void setup(float _x, float _y, float _h, 
             float _r, float _g, float _b, float _white,
             float min_light_contribute=0.05, 
             float linear_contribute=0.25, 
             float geometric_contribute=0.5);

  void move(float new_x, float new_y, float new_h);
            
  virtual void draw(g1_draw_context_class *context);
  virtual void think();
  ~g1_light_object_class();
};

extern g1_object_type g1_lightbulb_type;

#endif
