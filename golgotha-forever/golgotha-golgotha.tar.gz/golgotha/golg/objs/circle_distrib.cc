/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

static i4_float distrib[][3] =
{
  {  0.1119191, -0.2615892,  0.0809548 },
  { -0.0452529, -0.3379074,  0.1162292 },
  {  0.0279555, -0.3618025,  0.1316825 },
  {  0.1749611,  0.3536127,  0.1556534 },
  { -0.3699638, -0.1603638,  0.1625898 },
  {  0.2052169,  0.3553498,  0.1683875 },
  { -0.4332598,  0.1643958,  0.2147400 },
  {  0.3386490, -0.3234571,  0.2193077 },
  { -0.4117406, -0.3958438,  0.3262226 },
  { -0.5119566, -0.3265958,  0.3687644 },
  {  0.0235136, -0.6238471,  0.3897381 },
  { -0.4229256, -0.4791123,  0.4084147 },
  { -0.6360176,  0.2824885,  0.4843182 },
  {  0.3013742,  0.6421718,  0.5032111 },
  {  0.7283822, -0.4513522,  0.7342594 },
  { -0.7393920,  0.4438775,  0.7437278 },
  {  0.6292487,  0.6089329,  0.7667533 },
  {  0.6443001, -0.6544292,  0.8434002 },
  { -0.5181742, -0.7614983,  0.8483842 },
  { -0.1292248,  1.0149743,  1.0468719 },
  { -1.0265210, -0.0737772,  1.0591884 },
  {  1.0388487, -0.2767890,  1.1558188 },
  { -1.0874339,  0.1317726,  1.1998766 },
  {  0.2515588,  1.0682873,  1.2045196 },
  {  0.5765704, -0.9755095,  1.2840523 },
  {  0.0266290,  1.1391640,  1.2984036 },
  { -1.1406190, -0.2395954,  1.3584176 },
  { -1.0869348, -0.4419400,  1.3767383 },
  { -0.4602780,  1.1603298,  1.5582211 },
  {  1.2395019,  0.2034033,  1.5777378 },
  { -0.0542220, -1.2694477,  1.6144374 },
  { -1.1491087, -0.6274906,  1.7141951 },
  {  0.5080261,  1.2831039,  1.9044461 },
  { -1.0483423, -0.9411163,  1.9847215 },
  { -1.3191282, -0.5656053,  2.0600087 },
  { -1.3691046,  0.5233776,  2.1483714 },
  { -0.5854948, -1.3513192,  2.1688677 },
  {  1.3562519,  0.6796750,  2.3013772 },
  {  0.2330792, -1.5546416,  2.4712365 },
  {  1.5848205,  0.0088370,  2.5117340 },
  {  0.4695513, -1.5172555,  2.5225426 },
  {  1.4568255,  0.6415380,  2.5339116 },
  {  1.5364338, -0.4324282,  2.5476231 },
  {  1.5816531, -0.2210640,  2.5504959 },
  { -1.3291359, -0.9233928,  2.6192564 },
  {  0.8494235,  1.4087872,  2.7062018 },
  {  0.0659764,  1.6490205,  2.7236215 },
  {  1.5988521,  0.5281074,  2.8352254 },
  { -1.0747915, -1.3194717,  2.8961823 },
  { -1.2052282, -1.2147751,  2.9282535 },
};
