/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

#ifndef GUIDED_MISSILE_HH
#define GUIDED_MISSILE_HH

#include "g1_object.hh"
#include "player_type.hh"
#include "path.hh"
#include "sound/sfx_id.hh"
#include "objs/light_o.hh"

class g1_solid_class;
class g1_map_piece_class;
class g1_particle_emitter_class;
class g1_voice_class;

#define G1_GUIDED_MISSILE_DATA_VERSION 6

class g1_guided_missile_class : public g1_object_class
{
protected:  
  s1_sound_handle rumble_sound;

  i4_float damping_fraction;
  g1_typed_reference_class<g1_light_object_class> light;
public:
  g1_guided_missile_class(g1_object_type id, g1_loader_class *fp);
    
  virtual void setup(const i4_3d_vector &pos,
                     const i4_3d_vector &dir,
                     g1_object_class *this_guy_fired_me,
                     g1_object_class *track_me);

  virtual void start_sounds();

  virtual void add_explode();

  virtual void add_smoke();
  virtual void update_smoke();
  virtual void delete_smoke();
  virtual void request_remove();

  virtual void think();

  virtual i4_bool move(i4_float x_amount,
                       i4_float y_amount,
                       i4_float z_amount);
};

#endif
