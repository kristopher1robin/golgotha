/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

#ifndef DEBRIS_HH
#define DEBRIS_HH

#include "g1_object.hh"
#include "player.hh"
#include "path.hh"
#include "objs/model_draw.hh"

class g1_solid_class;
class g1_map_piece_class;

class g1_debris_class : public g1_object_class
{
protected:
  enum { MAX_DEBRIS = 200 };
  i4_3d_vector debris[MAX_DEBRIS],ldebris[MAX_DEBRIS];
  void make_chunk(int i);
  int type;
  i4_float rad, strength;
public:
  enum
  {
    TORNADO = 0,
    RING_CHUNKS,
  };
  virtual i4_float occupancy_radius() const { return 0.7; }

  g1_debris_class(g1_object_type id, g1_loader_class *fp);
  virtual void save(g1_saver_class *fp);

  virtual void setup(i4_float sx, i4_float sy, i4_float sz, int type);

  virtual void draw(g1_draw_context_class *context);
  virtual void think();
};

#endif
