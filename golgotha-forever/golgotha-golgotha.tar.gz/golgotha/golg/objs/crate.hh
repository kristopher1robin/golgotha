/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

#ifndef G1_CRATE_HH
#define G1_CRATE_HH


#include "g1_object.hh"
#include "resources.hh"

class g1_crate_class : public g1_object_class
{

  int ticks_to_think;

public:
  enum ctype { HEALTH,
               MISSILE,
               BULLET,
               CHAIN,
               MONEY,
               MAX_TYPES
  };

  enum atype { SMALL,
               LARGE };


  ctype get_type();
  void set_type(ctype x);

  atype get_amount();
  void set_amount(atype x);

  int &ticks_left();
  float &yvel(); 
  float float_height() { return 0.2; }

  int added_money();
  int added_bullets();
  int added_health();
  int added_missiles();
  int added_chain();
    

  g1_crate_class(g1_object_type id, g1_loader_class *fp);
  i4_bool occupy_location();
  void draw(g1_draw_context_class *context);

  void setup(const i4_3d_vector &pos, ctype t, atype amount, int ticks=-1);
  void think();
  void object_changed_by_editor(g1_object_class *who, li_class *old_values);
  void note_stank_near(g1_player_piece_class *s);
  void go_away();

};


#endif
