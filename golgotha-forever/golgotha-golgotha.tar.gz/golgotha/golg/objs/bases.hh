/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

#ifndef G1_BASES_HH
#define G1_BASES_HH

#include "isllist.hh"
#include "memory/que.hh"
#include "g1_object.hh"
#include "objs/structure_death.hh"

class g1_path_object_class;

struct g1_build_item
{
  int type;
  g1_id_ref *path;  // null terminated
};

class g1_factory_class : public g1_object_class
{
protected:
  g1_structure_death_class death;
  g1_map_piece_class *create_object(int type);
public:
  g1_factory_class *next;
  i4_fixed_que<g1_build_item, 50> deploy_que;
  
  g1_factory_class(g1_object_type id, g1_loader_class *fp);  
  void think();
  i4_bool occupy_location();
  void unoccupy_location();
  virtual g1_path_object_class *get_start();
  virtual void set_start(g1_path_object_class *start);
  virtual i4_bool build(int type);
  virtual w32 get_path_color();
  virtual w32 get_selected_path_color();

  void damage(g1_object_class *obj, int hp, i4_3d_vector damage_dir);
};

extern i4_isl_list<g1_factory_class> g1_factory_list;

#endif
