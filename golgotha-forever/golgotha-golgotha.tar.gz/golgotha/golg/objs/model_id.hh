/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

#ifndef G1_MODEL_ID_HH
#define G1_MODEL_ID_HH

#include "arch.hh"
#include "g1_limits.hh"
#include "memory/growheap.hh"
#include "init/init.hh"
#include "error/error.hh"
#include "memory/array.hh"

class i4_str;
class g1_quad_object_class;
class r1_render_api_class;
class r1_texture_manager_class;

typedef w16 g1_model_id_type;

// G3d model repository for the game
class g1_model_list_class : public i4_init_class
{
  friend int g1_model_info_compare(const void *a, const void *b);
  struct model_info
  {
    g1_quad_object_class *model;
    char *name_start;
  } *array;


  i4_grow_heap_class *name_buffer;
  int   total_models;

  virtual void init();
  virtual void uninit();

public:
  void reset(i4_array<i4_str *> &model_names, r1_texture_manager_class *tmap);


  g1_quad_object_class *get_model(w16 handle) const
  { 
    if (handle>=total_models)
      i4_error("get_model : bad handle");

    return array[handle].model; 
  }

  g1_model_id_type find_handle(const char *name) const;
  void cleanup();
  
  char *get_model_name(w16 handle) const
  {
    return array[handle].name_start;
  }
};

extern g1_model_list_class g1_model_list_man;


class g1_model_ref
{
public:
  char *name;
  g1_model_id_type value;
  g1_model_ref *next;
  
  g1_model_ref(char *name=0);  // assumes name is a static value (it is not copied)
  void set_name(char *name);
  ~g1_model_ref();

  g1_model_id_type id() const { return value; }
  g1_quad_object_class *get() const { return g1_model_list_man.get_model(value); }
  g1_quad_object_class *operator()() const { return g1_model_list_man.get_model(value); }
};

#endif
