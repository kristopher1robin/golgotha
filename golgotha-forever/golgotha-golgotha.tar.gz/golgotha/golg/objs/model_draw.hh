/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

#ifndef G1_MODEL_DRAW_HH
#define G1_MODEL_DRAW_HH

#include "arch.hh"

class g1_object_class;
class g1_draw_context_class;
class g1_quad_object_class;

struct g1_model_draw_parameters
{
  enum
  {
    SUPPRESS_SPECIALS=1,
    NO_LIGHTING=2            // draws object full-bright
  };

  g1_quad_object_class *model;
  g1_quad_object_class *shadow_model;
  g1_quad_object_class *lod_model;

  w16 frame;           // current animation frame
  w16 animation;       // current animation number in model
  w32 flags;           // drawing modifiers

  g1_model_draw_parameters()
  {
    model           = 0;
    shadow_model    = 0;
    lod_model       = 0;
    frame           = 0;
    animation       = 0;
    flags           = 0;
  }
  
  void setup(const char *model_name, char *shadow_model_name=0, char *lod_model_name=0);
  void setup(w16 model_id, w16 shadow_model=0, w16 lod_model=0);
  void setup(g1_quad_object_class *model, 
             g1_quad_object_class *shadow_model=0,
             g1_quad_object_class *lod_model=0);
  
  float extent() const;     // gets extents of model_id from model_draw
};

void g1_model_draw(g1_object_class *_this,
                   g1_model_draw_parameters &params,
                   g1_draw_context_class *context);


void g1_editor_model_draw(g1_object_class *_this,
                          g1_model_draw_parameters &params,
                          g1_draw_context_class *context);    // calls model draw if in edit mode

#endif
