/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

#include "objs/def_object.hh"
#include "lisp/li_class.hh"
#include "map_man.hh"
#include "map.hh"
#include "li_objref.hh"
#include "lisp/li_init.hh"
#include "object_definer.hh"

static li_object_class_member target("takeover_objects"), me_turret("turret");
static li_symbol_ref turret_obj("turret");

class g1_takeover_pad_class : public g1_object_class
{
public:
  g1_takeover_pad_class(g1_object_type id, g1_loader_class *fp)
    : g1_object_class(id,fp) {}

  void think() {}

  virtual void change_player_num(int new_team)
  //{{{
  {
    li_class_context c(vars);

    g1_object_class *turret=li_g1_ref::get(me_turret(),0)->value();
    if (!turret)
    {
      g1_object_class::change_player_num(new_team);
      
      li_g1_ref_list *list=li_g1_ref_list::get(target(),0);
      int list_size=list->size();
      for (int i=0; i<list_size; i++)  
      {
        g1_object_class *tar=list->value(i);
        if (tar)
        {
          tar->request_think();
          tar->change_player_num(player_num);
        }
      }
      
      g1_object_class *t = g1_create_object(g1_get_object_type(turret_obj.get()));
      if (t)
      {
        t->x = x;
        t->y = y;
        t->player_num = player_num;
        t->occupy_location();
        t->request_think();
        t->grab_old();
        
        me_turret() = new li_g1_ref(t->global_id);
      }      
    }
  }
  //}}}
};

g1_object_definer<g1_takeover_pad_class>
g1_takeover_pad_def("takeover_pad", g1_object_definition_class::EDITOR_SELECTABLE);

//{{{ Emacs Locals
// Local Variables:
// folded-file: t
// End:
//}}}
