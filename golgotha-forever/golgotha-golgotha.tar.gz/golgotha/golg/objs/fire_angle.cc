/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

#include "objs/fire_angle.hh"
#include "math/pi.hh"
#include <math.h>

i4_bool g1_calc_fire_angle(i4_float x_y_dist, 
                           i4_float z1, 
                           i4_float z2,
                           i4_float g,
                           i4_float vo,
                           i4_float &theta)
{  
  if (z1!=z2)
  {
    i4_float z_dist=z2-z1;
    i4_float b=x_y_dist * sqrt(1 - (4 * z_dist * g)/(2 * vo*vo));
    i4_float c=(2 * z_dist);

    // ignore the +b solution because it occurs in negative time

    i4_float cos_theta2=(x_y_dist - b)/c;
    if (cos_theta2>=-1 && cos_theta2<=1)      
    {
      theta=acos(cos_theta2);
      return i4_T;
    }
    return i4_F;
  }
  else
  {
    i4_float cos_theta=g * x_y_dist / (2 * vo*vo);

    if (cos_theta>=-1 && cos_theta<=1)
    {
      theta=acos(cos_theta);
      if (theta>=i4_pi()/4)
        theta=i4_pi()/2-theta;


      return i4_T;
    }
    return i4_F;
  }
}
