/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

#ifndef PARTICLE_EMITTER_HH
#define PARTICLE_EMITTER_HH

#include "g1_object.hh"
#include "tex_id.hh"
#include "file/file.hh"

struct g1_particle_emitter_params
{
  r1_texture_handle texture;
  
  i4_float start_size;
  i4_float start_size_random_range;  // added to start size

  i4_float grow_speed;
  i4_float grow_accel;
  i4_3d_vector speed;      // travel speed
  
  sw32     num_create_attempts_per_tick;
  i4_float creation_probability;     // 0..1 likelyhood each tick of creating a new particle
  i4_float max_speed;
  i4_float air_friction;
  i4_float gravity;

  sw32  particle_lifetime; // ticks particles will be around (they also die if size<0)
  sw32  emitter_lifetime;  // ticks the emitter will be around

  void defaults();
};

struct g1_particle_class
{  
  float x,y,z, lx,ly,lz;
  float xv, yv, zv;
  float grow_speed;
  float size;
  int   ticks_left;
  i4_bool in_use;

  void load(i4_file_class *fp);
  void save(i4_file_class *fp);
};

class g1_particle_emitter_class : public g1_object_class
{
  g1_object_chain_class cell_on;
  enum { DATA_VERSION=0xabce };
public:
  float x1,y1, x2,y2;             // ground plane bounds for occupy location
  float radius;
  i4_bool stopping;

  enum { MAX_PARTICLES=40  };
  g1_particle_class particles[MAX_PARTICLES];
  g1_particle_emitter_params params;
  
  int t_in_use;

  g1_particle_emitter_class(g1_object_type id, g1_loader_class *fp);
  virtual void save(g1_saver_class *fp);


  virtual i4_float occupancy_radius() const {  return radius; }

  void occupy_bounds();

  void setup(float x, float y, float h, g1_particle_emitter_params &params);
  virtual void draw(g1_draw_context_class *context);
  virtual void think();

  void stop() { stopping=i4_T; } 
  void move(float new_x, float new_y, float new_h);
  i4_bool occupy_location();
  void unoccupy_location();  
};




#endif
