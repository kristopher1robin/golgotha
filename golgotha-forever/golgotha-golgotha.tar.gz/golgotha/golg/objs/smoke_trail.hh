/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

#ifndef SMOKE_TRAIL_HH
#define SMOKE_TRAIL_HH

#include "g1_object.hh"
#include "player_type.hh"
#include "path.hh"

class g1_solid_class;
class g1_map_piece_class;
class g1_map_class;

/*
  To create a smoke trail call :

    s=(g1_smoke_trail_class *)g1_create_object(G1_SMOKE_TRAIL);
    if (s)
    {
      s->setup(x, y, h, 0.01, 0.2, 0xffd000, 0xffffff);   // orange to white
      s->occupy_location(map);
      smoke_trail.reference_object(0,s);
    }


  when you (the head of the smoke trail, move, call :
    if (s)
      s->update_head(map, x,y,h);

  when you die call :
    if (s)    // delete the smoke trail
    {
      s->unoccupy_location(map);
      map->request_remove(s);
    }

 */

class g1_smoke_trail_class : public g1_object_class
{
public:
  enum { DATA_VERSION=1 };
  enum { TAIL_LENGTH=4 };
  i4_3d_point_class tspots[TAIL_LENGTH];

  w32 last_draw_frame;
  w32 sc, ec;
  i4_float sw,ew;
  w16 ticks_advanced;

  virtual i4_float occupancy_radius() const 
  {
    float w=(tspots[0].x-tspots[TAIL_LENGTH-1].x);
    float h=(tspots[0].y-tspots[TAIL_LENGTH-1].y);

    w = (w<0)? w=-w : w;
    h = (h<0)? h=-h : h;

    return w>h ? w : h;
  }


  virtual void setup(i4_float start_x, i4_float start_y, i4_float start_h,
             i4_float start_width, i4_float end_width,
             i4_color start_color, i4_color end_color);

  virtual void update_head(i4_float nx, i4_float ny, i4_float nh);

  g1_smoke_trail_class(g1_object_type id, g1_loader_class *fp);
  virtual void save(g1_saver_class *fp);
  virtual void draw(g1_draw_context_class *context);
  virtual void think();
};

#endif
