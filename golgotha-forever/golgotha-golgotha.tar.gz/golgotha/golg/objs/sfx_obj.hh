/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

#ifndef G1_TAKEOVER_PAD_HH
#define G1_TAKEOVER_PAD_HH


#include "g1_object.hh"
#include "objs/model_draw.hh"

class i4_stream_wav_player;

extern g1_object_type g1_sfx_obj_type;

class g1_sfx_obj_class : public g1_object_class
{ 
  enum { DATA_VERSION=1 };
public:
  static g1_sfx_obj_class *cast(g1_object_class *obj)
  {
    if (!obj || obj->id != g1_sfx_obj_type)
    { 
#ifdef I4_CAST_WARN
      i4_warning("bad cast to sfx_obj!\n"); 
#endif
      return 0; 
    }
    
    return (g1_sfx_obj_class *)obj;
  }

  i4_stream_wav_player *stream;
  i4_str *filename;
  w16 max_volume;
  w32 max_hearable_distance;
  w32 restart_delay;
  w32 random_restart_delay;   
  w32 current_delay;         // time to count down until next sound is played
  float dist_from_camera_sqrd;    // calculated by g1_sound_man

  g1_sfx_obj_class *next_sfx;
  
  g1_sfx_obj_class(g1_object_type id, g1_loader_class *fp);
  ~g1_sfx_obj_class();
  virtual void save(g1_saver_class *fp);

  i4_str *get_context_string();  

  void set_filename(const i4_const_str &fname);

  // adds self to sound_manager
  i4_bool occupy_location();

  // remove self from sound_manager
  void unoccupy_location();
  virtual void draw(g1_draw_context_class *context);
  virtual void think();
};


#endif
