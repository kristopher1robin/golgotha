/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

#include "objs/chunk_explosion.hh"
#include "object_definer.hh"
#include "objs/explode_model.hh"
#include "map.hh"
#include "map_man.hh"
#include "lisp/lisp.hh"
#include "g1_rand.hh"
#include "objs/explosion1.hh"
#include "time/profile.hh"

static i4_profile_class pf_chunk_explosion("chunk_explosion");

g1_chunk_explosion_class::g1_chunk_explosion_class(g1_object_type id, g1_loader_class *fp)
  : g1_object_class(id, fp) {}

void g1_chunk_explosion_class::setup(const i4_3d_vector &pos,
                                     const i4_3d_vector &rotations,
                                     g1_quad_object_class *model,
                                     const i4_3d_vector &_dir,
                                     int ticks_till_explode)

{
  dir=_dir;
  dir.x=dir.x*0.1 + g1_float_rand(5)*0.04-0.08;
  dir.y=dir.y*0.1 + g1_float_rand(7)*0.04-0.08;
  dir.z=g1_float_rand(6)*0.1+0.1;

  avel.x=g1_float_rand(8)*0.2;
  avel.y=g1_float_rand(1)*0.2;
  avel.z=g1_float_rand(0)*0.4-0.2;
  
  ticks_left=ticks_till_explode;
      
  draw_params.setup(model);
  x=lx=pos.x;
  y=ly=pos.y;
  h=lh=pos.z;
  theta = rotations.z;
  pitch = rotations.y;
  roll = rotations.x;
  occupy_location();
  request_think();
}             
             
void g1_chunk_explosion_class::draw(g1_draw_context_class *context)
{
  g1_model_draw(this, draw_params, context);
}

static li_symbol_ref explode_model("explode_model");

float jc_f=0.0008;
float jc_l=0.2;

static li_symbol_ref explosion1("explosion1");

void g1_chunk_explosion_class::think()
{
  pf_chunk_explosion.start();

  if (!ticks_left)
  {
    g1_explode_model_class *e;
    e=(g1_explode_model_class *)g1_create_object(g1_get_object_type(explode_model.get()));
    g1_explode_params params;
    params.stages[0].setup(1, jc_f, G1_APPLY_SING);
    params.stages[1].setup(20, 0, G1_APPLY_SING);
    params.t_stages=2;
    e->setup(this, i4_3d_vector(0,0,0), params);

    g1_explosion1_class *explosion;
    explosion=(g1_explosion1_class *)g1_create_object(g1_get_object_type(explosion1.get()));
    explosion->setup(x,y,h);
         
    unoccupy_location();
    request_remove();
  }
  else
  {
    i4_3d_vector ray=dir;

    g1_object_class *hit;
    if (g1_get_map()->check_non_player_collision(0xff, i4_3d_vector(x,y,h), ray, hit))
      dir.z=-dir.z*0.75;

    unoccupy_location();
    grab_old();
    x+=ray.x;
    y+=ray.y;
    h+=ray.z;

    pitch+=avel.x;
    roll+=avel.y;
    theta+=avel.z;

    if (occupy_location())
      request_think();
    ticks_left--;
  }

  pf_chunk_explosion.stop();
}


g1_object_definer<g1_chunk_explosion_class> g1_chunk_explosion_def("chunk_explosion");



