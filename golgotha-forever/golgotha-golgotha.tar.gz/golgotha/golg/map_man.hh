/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

#ifndef G1_MAP_MAN_HH
#define G1_MAP_MAN_HH

#include "init/init.hh"
#include "memory/array.hh"
#include "g1_limits.hh"
#include "error/error.hh"

class g1_map_class;
class g1_map_cell_class;
class g1_map_vertex_class;

// these are mirrored from the current map, don't
// change them directly
extern g1_map_cell_class *g1_cells;
extern g1_map_vertex_class *g1_verts;
extern int g1_map_width, g1_map_height;
extern int g1_map_width_plus_one;

extern g1_map_class *g1_current_map_PRIVATE;

void g1_set_map(g1_map_class *map);

inline i4_bool g1_map_is_loaded()
{
  if (g1_current_map_PRIVATE)
    return i4_T;
  else return i4_F;
}

inline g1_map_class *g1_get_map()
{
#ifdef DEBUG
  if (!g1_current_map_PRIVATE)
    i4_error("map missing");
#endif
  return g1_current_map_PRIVATE;
}

void g1_destroy_map();

#endif
