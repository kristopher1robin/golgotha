/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

#include "map_vars.hh"
#include "lisp/li_load.hh"
#include "saver.hh"
#include "map.hh"
#include "lisp/lisp.hh"
#include "lisp/li_init.hh"
#include "lisp/li_dialog.hh"

void g1_map_vars_class::load(g1_loader_class *fp, w32 sections)
{
  if ((sections & G1_MAP_VARS) && fp)
    if (fp->goto_section("level vars"))
      var_ptr=li_load_typed_object("level_vars", fp, fp->li_remap,0);  
    else var_ptr=li_new("level_vars");

}


void g1_map_vars_class::save(g1_saver_class *fp, w32 sections)
{
  if (sections & G1_MAP_VARS)
  {
    fp->mark_section("level vars");
    li_save_object(fp, var_ptr.get(), 0);
  }

}

g1_map_vars_class g1_map_vars;

li_object *g1_set_level_vars(li_object *o, li_environment *env)
{
  g1_map_vars.var_ptr=li_car(o, env);
  return 0;
}



li_object *g1_edit_level_vars(li_object *o, li_environment *env)
{
  li_create_dialog("Level Vars", g1_map_vars.var_ptr.get(), 0, g1_set_level_vars);
  return 0;
}

li_automatic_add_function(g1_edit_level_vars, "edit_level_vars");



