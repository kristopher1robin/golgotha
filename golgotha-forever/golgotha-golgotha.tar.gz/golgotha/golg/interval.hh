/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

//{{{ Numeric Interval template
//
//  Allows the manipulation of numeric closed intervals, or the union of
//  all numbers that fall between pairs of numbers, inclusively.
//
//Usage:
//  Instantiate the template on a numeric type
//  Add intervals using 'add_interval', which also returns whether the specified
//    interval was not contained
//  Test for containment using 'contains'
//  Reset the interval with 'clear'
//  
//  To allow for printing of the interval list, define 'DEBUG_INTERVAL' and
//    use 'print' in the debugger.
//
//$Id: interval.hh,v 1.1.1.1 2001/11/02 19:51:11 rodal Exp $
//}}}

#include "arch.hh"
#include "math/num_type.hh"

template <class T>
class i4_interval_template
{
protected:
  class interval_node;
  typedef interval_node *interval_link;
  class interval_node
  //{{{
  {
    friend class i4_interval_template<T>;
  protected:
    interval_link left, right;
  public:
    T min, max;

    interval_node() : left(0), right(0) {}
    interval_node(T _min, T _max) 
      : min(_min), max(_max), left(0), right(0) {}

    ~interval_node() { delete left; delete right; }
  };
  //}}}
  interval_link root;

  interval_link *find_interval(T val, interval_link *pp)
  //{{{
  {
    interval_link p;

    while ((p = *pp)!=0)
    {
      if (val<p->min)
        pp = &p->left;
      else if (val>p->max)
        pp = &p->right;
      else
        return pp;
    }
    return pp;
  }
  //}}}

  i4_bool recurse_combine(interval_link *pp,
                          T min, 
                          T max, 
                          interval_link replace)
  //{{{
  {
    interval_link p = *pp;

    if (!p)
    {
      if (!replace)
      {
        *pp = new interval_node(min,max);
        return 1;
      }
      else
        return 0;
    }

    if (max<p->min)
      // interval totally to the left of me
      recurse_combine(&p->left,min,max,replace);
    else if (min>p->max)
      // interval totally to the right of me
      recurse_combine(&p->right,min,max,replace);
    else
    {
      // interval touches me
      T local_min, local_max;

      if (min<=p->min)
        // can possibly combine more to the left
        recurse_combine(&p->left,min,max,p);
      if (max>=p->max)
        // can possibly combine more to the right
        recurse_combine(&p->right,min,max,p);

      local_min = (min < p->min)? min : p->min;
      local_max = (max > p->max)? max : p->max;

      if (replace)
      {
        // combine me into my ancestor
        replace->min = (local_min < replace->min)? local_min : replace->min;
        replace->max = (local_max > replace->max)? local_max : replace->max;

        delete p;
        *pp = 0;
      }
      else
      {
        // combine interval with me
        p->min = local_min;
        p->max = local_max;
      }
    }
    return 0;
  }
  //}}}

  //{{{ Debugging Tools

#ifdef DEBUG_INTERVAL
  void print_tree(interval_link tree)
  //{{{
  {
    if (!tree)
      return;

    print_tree(tree->left);
    printf("[%f %f]\n",tree->min,tree->max);
    print_tree(tree->right);
  }
  //}}}
#endif
  
#ifdef DEBUG_INTERVAL
public:
  void print()
  //{{{
  {
    print_tree(root);
  }
  //}}}
protected:
#endif
  
  //}}}
  
public:
  i4_interval_template() : root(0) {}
  
  i4_bool contains(T val)
  //{{{
  {
    return (*find_interval(val,&root) != 0);
  }
  //}}}

  i4_bool add_interval(T min, T max)
  //{{{
  {
    return recurse_combine(&root,min,max,0);
  }
  //}}}

  void clear()
  //{{{
  {
    if (root)
      delete root;
    root = 0;
  }
  //}}}
};

//{{{ Emacs Locals
// Local Variables:
// folded-file: t
// End:
//}}}
