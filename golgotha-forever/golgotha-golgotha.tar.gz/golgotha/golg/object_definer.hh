/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

#ifndef G1_OBJECT_DEFINER_HH
#define G1_OBJECT_DEFINER_HH

#include "g1_object.hh"
#include "objs/defaults.hh"

// this can be used to generate a definition class for an object and automatically add it into 
// the game via it's global constructor, I think this will work with dlls as well because
// their global constructors are called when a dll is loaded

template <class T>
class g1_object_definer : public g1_object_definition_class
{
public:
  g1_object_definer<T>(char *name,
                       w32 type_flags=0,
                       function_type _init = 0,
                       function_type _uninit = 0)
    : g1_object_definition_class(name, type_flags ,_init, _uninit) {}

  virtual g1_object_class *create_object(g1_object_type id,
                                         g1_loader_class *fp)
  {
    T *o=new T(id, fp);
    o->init();
    return o;
  }
};

class li_object;
class li_environment;

// called from g1_load_level (level_load.cc) : creates and objects type from lisp token
void g1_define_object(li_object *o, li_environment *env);

#endif
