/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

#ifndef G1_SOLVEMAP_HH
#define G1_SOLVEMAP_HH

#include "arch.hh"
#include "math/num_type.hh"

class g1_block_map_class;
class g1_map_solver_class
{
public:
  g1_map_solver_class() {}

  virtual void set_block_map(g1_block_map_class *_block) = 0;
  virtual i4_bool path_solve(w32 startx, w32 starty, w32 destx, w32 desty, 
                             w8 sizex, w8 sizey, w8 grade,
                             i4_float *point, w16 &points) = 0;
};

#endif

//{{{ Emacs Locals
// Local Variables:
// folded-file: t
// End:
//}}}
