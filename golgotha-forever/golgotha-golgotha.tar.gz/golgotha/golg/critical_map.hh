/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

#ifndef CRITICAL_MAP_HH
#define CRITICAL_MAP_HH

#include "arch.hh"
#include "critical_graph.hh"

class g1_map_class;

class g1_critical_map_maker_class
{
protected:
  g1_map_class *map;
  g1_critical_graph_class *critical;

  enum { queue_length=22500 };
  w32 cnx[queue_length], cny[queue_length];
  g1_graph_node crit[queue_length];
  w32 head,tail;

  void clear_queue() { head = tail = 0; }

  // critical map accessors
  i4_bool critical_full(w16 x, w16 y, g1_graph_node crit);
  void set_critical(w16 x, w16 y, g1_graph_node critical);

  i4_bool add_critical(w32 x,w32 y,w8 d, g1_graph_node critical);
  i4_bool get_next_critical(w32 &x,w32 &y, g1_graph_node &critical);

  i4_bool make_critical_map();
  i4_bool make_critical_graph();

  void clear_critical_map();
public:
  w8 grade, tofrom;
  g1_graph_node get_critical(w16 x, w16 y, int n=0);

  // returns false if canceled by user
  i4_bool make_criticals(g1_map_class *_map, g1_critical_graph_class *_graph);
  g1_critical_map_maker_class() 
    : map(0), critical(0) {}
};

#endif

//{{{ Emacs Locals
// Local Variables:
// folded-file: t
// End:
//}}}

