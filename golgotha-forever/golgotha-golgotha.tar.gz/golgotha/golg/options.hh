/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

#ifndef G1_OPTIONS_HH
#define G1_OPTIONS_HH


#include "window/colorwin.hh"
#include "device/device.hh"
#include "gui/image_win.hh"

class i4_graphical_style_class;
class i4_event_handler_class;
class i4_button_class;
class i4_const_str;

class g1_option_window : public i4_parent_window_class
{
  i4_graphical_style_class *style;
  i4_image_class *options_background;
  i4_event_handler_reference_class<i4_image_window_class> shadow_image_win, sound_image_win;

  i4_button_class *create_button(const i4_const_str &help, 
                                 int im,
                                 i4_event_handler_reference_class<i4_image_window_class> *win_ref,
                                 int mess_id);
  void add_buttons();

  enum { STOPPED,
         SLIDE_RIGHT,
         SLIDE_LEFT
  } mode;

  int get_correction();
  int slide_speed, slide_left, slide_correction;

public:
  enum 
  {
    SLIDE_AWAY,
    SLIDE,
    VIS_LOW,
    VIS_MEDIUM,
    VIS_HIGH,

    NORMAL_PIXEL,
    INTERLACE,
    DOUBLE_PIXEL,
    SOUND, 

    SHADOWS,
    GAME_SPEED
  };

  ~g1_option_window();
  void parent_draw(i4_draw_context_class &context);
  void forget_redraw();
  g1_option_window(i4_graphical_style_class *style);

  void receive_event(i4_event *ev);
  char *name() { return "g1_option_window"; }
};


extern i4_event_handler_reference_class<g1_option_window> g1_options_window;

#endif

