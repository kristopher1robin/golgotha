/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

#include "map.hh"
#include "g1_object.hh"
#include "m_flow.hh"



i4_bool g1_map_class::start_movie()
{
  if (!current_movie || !current_movie->current())
    return i4_F;
    
  current_movie->start();
  movie_in_progress=i4_T;
  
  g1_object_class *o[G1_MAX_OBJECTS];
  int t=make_object_list(o,G1_MAX_OBJECTS);
  
  for (int i=0; i<t; i++)
    o[i]->request_think();

  tick_time.get();

  return i4_T;
}

void g1_map_class::stop_movie()
{
  if (current_movie)
    current_movie->stop();

  movie_in_progress=i4_F;
}

i4_bool g1_map_class::advance_movie_with_time()
{
  if (current_movie)
  {
    g1_movie_flow_class::advance_status stat;
    stat=current_movie->advance_movie_with_time();
    if (stat==g1_movie_flow_class::DONE)
    {
      movie_in_progress=i4_F;
      return i4_F;
    }

    if (stat==g1_movie_flow_class::NEXT_SCENE)
    {
      g1_object_class *o[G1_MAX_OBJECTS];
      int t=make_object_list(o,G1_MAX_OBJECTS);
  
      for (int i=0; i<t; i++)
        o[i]->request_think();
    }
    return i4_T;
  }
  else
    return i4_F;
}
