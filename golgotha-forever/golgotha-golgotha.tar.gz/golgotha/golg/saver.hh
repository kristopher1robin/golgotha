/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

#ifndef G1_SAVER_HH
#define G1_SAVER_HH

#include "file/file.hh"
#include "memory/growarry.hh"
#include "path.hh"
#include "reference.hh"
#include "loaders/dir_load.hh"
#include "loaders/dir_save.hh"
#include "lisp/li_types.hh"
#include "global_id.hh"

class g1_path_saver_class;
class g1_object_class;


struct g1_saver_section_type
{
  w16 section_id;
  w32 section_offset;
  g1_saver_section_type(w16 section_id, w32 section_offset)
    : section_id(section_id),
      section_offset(section_offset)
  {}
};


class g1_saver_class : public i4_saver_class
{
  g1_object_class **ref_list;
  w32 t_refs;
  g1_global_id_manager_class::remapper *remap;

public: 
  g1_saver_class(i4_file_class *out, i4_bool close_on_delete=i4_T);
  ~g1_saver_class();

  void set_helpers(g1_object_class **reference_list, w32 total_references);
  virtual i4_bool write_reference(const g1_reference_class &ref);
  i4_bool write_global_id(w32 id);
};

class g1_loader_class : public i4_loader_class
{
  g1_object_class **ref_list;
  w32 t_refs;
  g1_reference_class *first_ref;
  w32 *id_remap;

public: 
  li_type_number *li_remap;    // used to load lisp objects

  i4_bool references_were_loaded() { return first_ref!=0; }

  g1_loader_class(i4_file_class *in, i4_bool close_on_delete=i4_T);

  void set_remap(w32 total_refs);
  void end_remap();

  void set_helpers(g1_object_class **reference_list, w32 total_references);

  void read_reference(g1_reference_class &ref);
  w32 read_global_id();

  // called by level loader after all objects have been loaded
  void convert_references();

  ~g1_loader_class();
};

// returns NULL if file is corrupted
g1_loader_class *g1_open_save_file(i4_file_class *in,
                                   i4_bool close_on_delete_or_fail=i4_T);

#endif



