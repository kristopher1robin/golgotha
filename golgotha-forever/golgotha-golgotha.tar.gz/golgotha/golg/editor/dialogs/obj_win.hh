/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

#ifndef OBJECT_WINDOW_HH
#define OBJECT_WINDOW_HH

#include "window/window.hh"
#include "g1_limits.hh"
#include "menu/menuitem.hh"
#include "editor/dialogs/pick_win.hh"
#include "g1_object.hh"
#include "reference.hh"

class g1_object_class;
class r1_render_api_class;

class g1_3d_object_window : public g1_3d_pick_window
{
public:
  g1_typed_reference_class<g1_object_class> object;
  g1_object_type      object_type;
  w16                 array_index;

  i4_menu_item_class *copy() { return new g1_3d_object_window(width(), height(), 
                                                              object.valid() ? object->id : 0,
                                                              array_index,
                                                              camera,
                                                              act, pass, reaction->copy()); }

  void set_object_type(g1_object_type type, w16 array_index);

  g1_3d_object_window(w16 w, w16 h,
                      g1_object_type obj_type,
                      w16 array_index,
                      g1_3d_pick_window::camera_struct &camera,
                      i4_image_class *active_back,
                      i4_image_class *passive_back,
                      i4_event_reaction_class *reaction);


  void draw_object(g1_draw_context_class *context);

  i4_bool selected();
  void do_press();

  void do_idle();

  char *name() { return "object window"; }
} ;


#endif
