/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

#ifndef TILE_WINDOW_HH
#define TILE_WINDOW_HH


#include "window/window.hh"
#include "g1_limits.hh"
#include "menu/menuitem.hh"
#include "editor/dialogs/pick_win.hh"

class g1_quad_object_class;

class g1_3d_tile_window : public g1_3d_pick_window
{
  g1_quad_object_class *object;

  public :
  int tile_num;

  void set_tile_num(int num) 
  { 
    tile_num=num;
    request_redraw(i4_F);
  }

  g1_3d_tile_window(w16 w, w16 h,
                    int tile_num,
                    g1_3d_pick_window::camera_struct &camera,
                    i4_image_class *active_back,
                    i4_image_class *passive_back,
                    i4_event_reaction_class *reaction);

  i4_bool selected();
  void do_press();
  void draw_object(g1_draw_context_class *context);
  i4_menu_item_class *copy() { return new g1_3d_tile_window(width(), height(),
                                                            tile_num,
                                                            camera, act, pass,
                                                            reaction->copy()); }
  
  char *name() { return "object window"; }
} ;


#endif



