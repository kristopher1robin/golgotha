/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

#ifndef PATH_WIN_HH
#define PATH_WIN_HH

#include "math/num_type.hh"
#include "gui/butbox.hh"
#include "window/window.hh"
#include "image/image32.hh"

class g1_path_tool_window_class : public i4_button_box_class
{
protected:
  i4_image_class *grade_icon[4], *size_icon[2];
  i4_const_str *grade_help[4], *size_help[2];
public:
  g1_path_tool_window_class(i4_graphical_style_class *style, i4_event_handler_class *send_to,
                            int buttons, i4_image_class **img, i4_const_str **help_names);
  
  char *name() { return "path_tool_win"; }
};

class g1_map_class;
class g1_critical_graph_class;
class g1_critical_map_maker_class;
class g1_astar_map_solver_class;
class g1_breadth_first_graph_solver_class;

class g1_path_window_class : public i4_parent_window_class
{
protected:
  i4_image_class *start_icon, *dest_icon, *crit_icon;
  int last_x, last_y;
  int map_changed;

  i4_float point[1024];
  w16 points;
  
public:
  enum { CELL_SIZE=3 };

  class coord 
  { 
  public:
    w16 x,y; 

    coord() : x(0), y(0) {}
  } start, dest;      // path to solve

  int mode;                  // current lay down mode from tool window
  
  w16 grade;
  w8 size;
  w8 tofrom;
  g1_map_class *map;
  g1_critical_graph_class *critical_graph;
  
  g1_critical_map_maker_class *maker;
  g1_astar_map_solver_class *solvemap;
  g1_breadth_first_graph_solver_class *solvegraph;
  
  i4_image32 *bitmap;

  g1_path_window_class(g1_map_class *map, i4_image_class **icons);
  ~g1_path_window_class();

  w32 critical_color(w16 x, w16 y);
  
  void solve();
  void changed() { map_changed = 1; request_redraw(); }

  void draw_to_bitmap();
  void parent_draw(i4_draw_context_class &context);
  virtual void receive_event(i4_event *ev);

  
  char *name() { return "path_win"; }
};

#endif
