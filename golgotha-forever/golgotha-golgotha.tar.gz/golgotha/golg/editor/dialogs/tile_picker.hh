/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

#ifndef G1_TILE_PICKER_HH
#define G1_TILE_PICKER_HH


#include "window/window.hh"
#include "window/colorwin.hh"
#include "memory/array.hh"
#include "editor/dialogs/scroll_picker.hh"
#include "editor/dialogs/pick_win.hh"


class g1_tile_picker_class : public g1_scroll_picker_class
{
  i4_image_class *active_back;
  i4_image_class *passive_back;


  // this should return 0 if scroll_object_num is too big
  virtual i4_window_class *create_window(w16 w, w16 h, int scroll_object_num);
  virtual void change_window_object_num(i4_window_class *win, int new_scroll_object_num);
  virtual void rotate();
  virtual void mirror();
  virtual int total_objects();
public:

  g1_tile_picker_class(i4_graphical_style_class *style, 
                       g1_scroll_picker_info *info,
                       i4_image_class *active_back,
                       i4_image_class *passive_back);



};


#endif

