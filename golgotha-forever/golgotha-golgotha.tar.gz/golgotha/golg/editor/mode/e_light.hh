/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

#ifndef LIGHT_MODE_HH
#define LIGHT_MODE_HH


#include "editor/e_state.hh"
#include "editor/mode/e_mode.hh"

class g1_light_mode : public g1_mode_handler
{
public:
  virtual state current_state();
  g1_light_mode(g1_controller_edit_class *c) : g1_mode_handler(c) {}
};


class g1_light_params : public g1_mode_creator
{
public:
  char *name() { return "LIGHT"; }
  enum 
  {
    ROTATE,
    ZOOM,
    MOVE,
    SELECT,
    GDARKEN,
    GBRIGHTEN,
    DDARKEN,
    DBRIGHTEN,
    AMBIENT,
    GDARKEN_REP,
    GBRIGHTEN_REP,
    DDARKEN_REP,
    DBRIGHTEN_REP,
  } ;

  void create_buttons(i4_parent_window_class *container);

  g1_mode_handler *create_mode_handler(g1_controller_edit_class *c)
  { return new g1_light_mode(c); }


  void receive_event(i4_event *ev);
} ;

extern g1_light_params g1_e_light;



#endif
