/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

#include "editor/contedit.hh"
#include "device/event.hh"
#include "window/win_evt.hh"
#include "device/kernel.hh"
#include "editor/e_state.hh"
#include "tile.hh"
#include "device/keys.hh"
#include "editor/mode/e_mode.hh"
#include "editor/editor.hh"


void g1_controller_edit_class::receive_event(i4_event *ev)
{
  g1_object_controller_class::receive_event(ev);

  if (!g1_map_is_loaded()) return ;
  if (!active())
  {
    if (ev->type()==i4_event::WINDOW_MESSAGE)
    {
      CAST_PTR(wev, i4_window_message_class, ev);
      if (wev->sub_type==i4_window_message_class::LOST_KEYBOARD_FOCUS)
        unfocused();
      return;
    }              
    else if (ev->type()==i4_event::MOUSE_BUTTON_DOWN)      
    {
      focused();
      g1_current_controller=this;

      request_redraw();
      setup_context();
      if (!mode->pass_through_focus_click())
        return;
    }
    else
    {
      if (ev->type()==i4_event::MOUSE_MOVE)
      {
        CAST_PTR(mev, i4_mouse_move_event_class, ev);
        last_mouse_x=mev->x;
        last_mouse_y=mev->y;

        if (abs((sw32)last_mouse_x-(sw32)g1_edit_state.context_help.mx)>15 ||
            abs((sw32)last_mouse_y-(sw32)g1_edit_state.context_help.my)>15)
          g1_edit_state.context_help.hide();

      }

      update_cursor();
      return;
    }
  }


  switch (ev->type())
  {
    case i4_event::IDLE_MESSAGE :
    {
      if (active())
        mode->idle();
    } break;


    case i4_event::MOUSE_MOVE :
    {
      CAST_PTR(mev, i4_mouse_move_event_class, ev);
      setup_context();
      mode->mouse_move(mev->x, mev->y);
      last_mouse_x=mev->x;
      last_mouse_y=mev->y;

      if (abs((sw32)last_mouse_x-(sw32)g1_edit_state.context_help.mx)>15 ||
          abs((sw32)last_mouse_y-(sw32)g1_edit_state.context_help.my)>15)
        g1_edit_state.context_help.hide();

    } break;
    
    case i4_event::MOUSE_BUTTON_DOWN :
    {
      CAST_PTR(bev, i4_mouse_button_down_event_class, ev);
      if (bev->left())
      {
        setup_context();
        mode->mouse_down();
      }
    } break;

    case i4_event::MOUSE_BUTTON_UP :
    {
      CAST_PTR(bev, i4_mouse_button_up_event_class, ev);
      if (bev->left())
      {
        setup_context();
        mode->mouse_up();
      }
    } break;

    case i4_event::KEY_PRESS :
    {
      CAST_PTR(kev, i4_key_press_event_class, ev);
      setup_context();
      mode->key_press(kev);
    } break;

    case i4_event::WINDOW_MESSAGE :
    {
      CAST_PTR(wev, i4_window_message_class, ev);
      switch (wev->sub_type)
      {
        case i4_window_message_class::LOST_KEYBOARD_FOCUS :
          unfocused();
          break;

        case i4_window_message_class::LOST_MOUSE_FOCUS :
          mode->hide_focus();
          break;

        case i4_window_message_class::GOT_MOUSE_FOCUS :
          mode->show_focus();
          break;

      default:
	i4_warning("g1_controller_edit_class::receive_event() - unhandled sub-type = %d",int(wev->sub_type));
	break;
      }
    } break;

  default:
    i4_warning("g1_controller_edit_class::receive_event() - unhandled type = %d",int(ev->type()));
    break;

 
  }
}



