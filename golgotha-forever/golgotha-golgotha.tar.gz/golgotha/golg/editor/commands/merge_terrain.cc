/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

#include "editor/editor.hh"
#include "file/get_filename.hh"
#include "saver.hh"
#include "mess_id.hh"

void g1_editor_class::merge_terrain()
{
  i4_create_file_open_dialog(style,
                             get_editor_string("merge_ter_title"),
                             get_editor_string("merge_ter_start_dir"),
                             get_editor_string("merge_ter_file_mask"),
                             get_editor_string("merge_ter_mask_name"),
                             this,
                             G1_TMERGE_FILE_OPEN_OK,
                             G1_TMERGE_FILE_OPEN_CANCEL);


}

i4_bool g1_editor_class::merge_terrain_ok(i4_user_message_event_class *ev)
{
  CAST_PTR(f, i4_file_open_message_class, ev);

 
  i4_bool ret=i4_F;
  if (get_map())
  {
    i4_file_class *in=i4_open(*f->filename);
    if (in)
    {
      g1_loader_class *l=g1_open_save_file(in);
    
      if (l)
      {
        g1_editor_instance.add_undo(G1_MAP_CELLS | G1_MAP_VERTS);

        get_map()->load(l, G1_MAP_CELLS | G1_MAP_VERTS);
        delete l;
        ret=i4_T;
      }

      delete in;
    } 
  }

  return ret;
}

