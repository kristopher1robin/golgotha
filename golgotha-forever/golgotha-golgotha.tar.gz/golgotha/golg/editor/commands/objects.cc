/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

#include "map_man.hh"
#include "map.hh"
#include "lisp/li_init.hh"
#include "lisp/lisp.hh"
#include "objs/map_piece.hh"
#include "resources.hh"
#include "window/colorwin.hh"
#include "window/style.hh"
#include "gui/text_input.hh"
#include "gui/text.hh"
#include "app/app.hh"

li_object *g1_full_health(li_object *o, li_environment *env)
{
  g1_object_class *olist[G1_MAX_OBJECTS];
  sw32 t=g1_get_map()->make_object_list(olist, G1_MAX_OBJECTS);

  li_call("add_undo", li_make_list(new li_int(G1_MAP_OBJECTS)));

  for (int i=0; i<t; i++)
  {
    if (olist[i]->selected())
      olist[i]->health=olist[i]->get_type()->defaults->health;
  }

  li_call("redraw");

  return 0;
}

class g1_set_health_dialog_class : public i4_color_window_class
{
protected:
  i4_text_window_class *caption;
  i4_text_input_class *input;
public:
  g1_set_health_dialog_class(i4_graphical_style_class *style)
    : i4_color_window_class(300,50,style->color_hint->neutral(),style)
  {
    sw32 health = 0;
    g1_object_class *olist[G1_MAX_OBJECTS];
    sw32 t=g1_get_map()->make_object_list(olist, G1_MAX_OBJECTS);
    for (int i=0; i<t; i++)
      if (olist[i]->selected())
        health = olist[i]->health;

    char buf[256];
    sprintf(buf, "%d", int(health));
        
    caption = new i4_text_window_class(       "Health:",style);
    add_child(10,8,caption); 
    input   = new i4_text_input_class (style, buf,100,40, this);
    add_child(100,5,input);
  }

  virtual void receive_event(i4_event *ev)
  {
    switch (ev->type())
    {
      case i4_event::OBJECT_MESSAGE:
      {
        CAST_PTR(tev, i4_text_change_notify_event, ev);
        
        i4_str::iterator p = tev->new_text->begin();
        sw32 health = p.read_number();

        g1_object_class *olist[G1_MAX_OBJECTS];
        sw32 t=g1_get_map()->make_object_list(olist, G1_MAX_OBJECTS);
        
        li_call("add_undo", li_make_list(new li_int(G1_MAP_OBJECTS)));

        for (int i=0; i<t; i++)
          if (olist[i]->selected())
            olist[i]->health=health;

        li_call("redraw");

        style->close_mp_window(parent);
      } break;

      default:
        i4_color_window_class::receive_event(ev);
        break;
    }
  }
};

static i4_event_handler_reference_class<g1_set_health_dialog_class> g1_set_health_dialog;

li_object *g1_set_health(li_object *o, li_environment *env)
{
  if (!g1_set_health_dialog.get())
  {
    i4_graphical_style_class *style = i4_current_app->get_style();
    g1_set_health_dialog = new g1_set_health_dialog_class(style);
    
    style->create_mp_window(-1,-1, 
                            g1_set_health_dialog->width(),
                            g1_set_health_dialog->height(),
                            "Set Health")
      ->add_child(0,0,g1_set_health_dialog.get());
  }
  return 0;
}
li_automatic_add_function(g1_set_health,"set_health");
