/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

#include "lisp/li_init.hh"
#include "lisp/lisp.hh"
#include "g1_render.hh"
#include "r1_api.hh"
#include "tmanage.hh"

li_object *g1_wireframe(li_object *o, li_environment *env)
{
  g1_render.draw_mode=g1_render_class::WIREFRAME;  
  li_call("redraw");
  return 0;
}

li_object *g1_textured(li_object *o, li_environment *env)
{
  g1_render.draw_mode=g1_render_class::TEXTURED;  
  li_call("redraw");
  return 0;
}

li_object *g1_solid_color(li_object *o, li_environment *env)
{
  g1_render.draw_mode=g1_render_class::SOLID;  
  li_call("redraw");
  return 0;
}



li_object *g1_toggle_texture_loading(li_object *o, li_environment *env)
{  
  g1_render.r_api->get_tmanager()->toggle_texture_loading();
  return 0;
}

li_automatic_add_function(g1_toggle_texture_loading, "View/Toggle Texture Loading");
li_automatic_add_function(g1_wireframe, "View/Wireframe");
li_automatic_add_function(g1_textured, "View/Textured");
li_automatic_add_function(g1_solid_color, "View/Solid");
