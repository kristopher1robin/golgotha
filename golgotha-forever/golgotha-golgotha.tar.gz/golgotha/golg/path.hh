/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

#ifndef G1_PATH_HH
#define G1_PATH_HH

#include "arch.hh"
#include "math/num_type.hh"
#include "memory/growarry.hh"

class g1_saver_class;
class g1_loader_class;

// this is defined internally in path.cc, you don't need to know the details, use
// the path manager to find out info about your path
class g1_path_class;

typedef g1_path_class *g1_path_handle;

class g1_path_manager_class
{
public:
  g1_path_handle alloc_path(w32 t_positions,
                            i4_float *positions);

  void get_position(g1_path_handle path, i4_float &x, i4_float &y);
  i4_bool get_nth_position(g1_path_handle path, int n, i4_float &x, i4_float &y);

  // advance_path automatically frees the path after the last
  // reference gets to the end of it
  g1_path_handle advance_path(g1_path_handle path);

  i4_bool is_last_path_point(g1_path_handle path);
  
  void free_path(g1_path_handle &path);
      
  void save(g1_saver_class *fp, g1_path_handle path);
  g1_path_handle load(g1_loader_class *fp);
};

extern g1_path_manager_class g1_path_manager;

#endif
