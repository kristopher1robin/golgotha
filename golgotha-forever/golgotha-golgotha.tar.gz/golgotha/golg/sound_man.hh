/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

#ifndef G1_SOUND_MAN_HH
#define G1_SOUND_MAN_HH

#include "sound/sound.hh"
#include "memory/que.hh"
#include "math/transform.hh"


class g1_sound_manager_class;
class g1_sfx_obj_class;


class g1_sound_manager_class
{
public:
  g1_sfx_obj_class *sfx_obj_list;
  i4_bool loop_current_song;

  g1_sound_manager_class();
  void add_sfx_to_list(g1_sfx_obj_class *sfx);
  void remove_sfx_from_list(g1_sfx_obj_class *sfx);

  // should be calle by main game every tick, check to see if a new narative should be played
  // and to update the position of the 3d listener
  void poll(i4_bool game_is_running);   

  void pause();
  void unpause();
  void next_song();
};

extern g1_sound_manager_class g1_sound_man;

#endif
