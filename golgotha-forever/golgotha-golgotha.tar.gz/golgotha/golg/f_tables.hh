/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

#ifndef G1_F_TABLES_HH
#define G1_F_TABLES_HH



#include "math/point.hh"
#include "math/num_type.hh"

extern float g1_table_0_31_to_n1_1[32];   // maps 5 bits of integer into float range -1 to 1  
extern float g1_table_0_31_to_0_1[32];    // maps 5 bits of integer into float range 0 to 1
extern float g1_table_0_255_to_0_1[256];

extern float g1_shadow_sub_0_63_to_0_1_red_or_green[64];  // used in map_vert.hh for cloud shadows
extern float g1_shadow_sub_0_63_to_0_1_blue[64];



inline w16 g1_normal_to_16(i4_3d_vector v)
{
  w32 x=i4_f_to_i((v.x+1.0)*15.5),
    y=i4_f_to_i((v.y+1.0)*15.5),
    z=i4_f_to_i((v.z+1.0)*15.5);

  return (x<<10)|(y<<5)|z;    
}


#endif
