/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

#include "reference.hh"
#include "g1_object.hh"


void g1_reference_class::remove_ref()
{
  i4_isl_list<g1_reference_class>::iterator i=ref->ref_list.begin(), last=ref->ref_list.end();

  for (; i!=ref->ref_list.end(); ++i)
  {
    if ((&*i)==this)
    {
      if (last==ref->ref_list.end())
        ref->ref_list.erase();
      else        
        ref->ref_list.erase_after(last);
      ref=0;
      return;
    }
    last=i;
  }
  i4_error("remove reference : not found");
}

void g1_reference_class::reference_object(g1_object_class *object_being_referenced)
{
  if (ref)
    remove_ref();

  if (object_being_referenced)
  {
    ref=object_being_referenced;

    ref->ref_list.insert(*this);
  }
  else 
    ref=0;
}

g1_reference_class::~g1_reference_class()
{
  if (ref) remove_ref();
}
