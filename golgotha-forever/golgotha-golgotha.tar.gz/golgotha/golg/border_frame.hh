/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

#ifndef BORDER_FRAME_HH
#define BORDER_FRAME_HH


#include "window/window.hh"
#include "string/string.hh"
#include "memory/array.hh"
#include "window/colorwin.hh"


//---------------------------------
// Forward/Extern Declorations
//---------------------------------
class i4_button_class;
class i4_image_class;
class i4_graphical_style_class;


//------------------------------------------------------------------------------------------------
// G1_Border_Frame_Class -
//   
//           this window is responsible for drawing the border area around the game window's
//           it also loads the board frame from disk when need.  My hope is that during the normal
//           game it can free up the memory associated with the border.
//           ? bottom edge stat screen ?
//-----------------------------------------------------------------------------------------------

class g1_border_frame_class : public i4_color_window_class
{
    public:

    private:

      enum { OPTIONS, BUILD_FIRST,BUILD_LAST=BUILD_FIRST+0x1000,ACTIVE_FIRST,ACTIVE_LAST=ACTIVE_FIRST+0x1000};
         // left justify draw number with commas if needed

      enum { REFRESH_FRAME=1,REFRESH_ALL=REFRESH_FRAME*2-1};

      struct last_struct
       {
          int money, ammo[4], cost, frame_upgrade_level;
          int lives;
          last_struct() { memset(this, 0, sizeof(*this)); }
       }last;


      int refresh;
      void reparent(i4_image_class *draw_area, i4_parent_window_class *parent);

  public:  
 
      g1_border_frame_class();
     ~g1_border_frame_class();
    
     int shrink;    // how many pixels the 3d view is shrinked in for speed-up
     i4_image_class *frame;
     i4_bool mouse_grabbed;
     i4_bool strategy_on_top;

     i4_window_class *strategy_window;
     i4_window_class *controller_window;
     i4_window_class *radar_window;
 

     int border_x();
     int border_y();
     void relocate(i4_parent_window_class *w, char *loc, int x, int y);
     void resize_controller(int shrink_add);
     void set_strategy_on_top(i4_bool v);
     void update();       // check for changes in the game 
     virtual void parent_draw(i4_draw_context_class &context);
     virtual void draw(i4_draw_context_class &context);
     void receive_event(i4_event *ev);
     char *name() { return "border_frame"; }

};


//------------------------------------------------------------------------------------------
//  G1_Strategy_Screen_Class - ?right side pop-up screen ?
//
//-----------------------------------------------------------------------------------------
class g1_strategy_screen_class : public i4_color_window_class
{
     enum { OPTIONS, BUILD=1, ACTIVE=100 };
     i4_array<i4_button_class *> build_buttons;

  public:

     int shrink;              // how many pixels the 3d view is shrinked in for speed-up
     i4_image_class *frame;

     int border_x();
     int border_y();
     void create_build_buttons();
     virtual void parent_draw(i4_draw_context_class &context);
     g1_strategy_screen_class();
     void receive_event(i4_event *ev);
     char *name() { return "strategy_screen"; }
};



//------------------------------
// Forward/Extern Declorations
//------------------------------
extern i4_event_handler_reference_class<g1_border_frame_class> g1_border;
extern i4_event_handler_reference_class<g1_strategy_screen_class> g1_strategy_screen;

w32 g1_get_upgrade_color(int upgrade_level);  // used for font colors & border edges


//--------------------------------------------------------------------
// G1_Help_Screen_Class  - pop-up help screen
//--------------------------------------------------------------------
class g1_help_screen_class : public i4_parent_window_class
{
  
     i4_image_class *help;
     w32 mess_id_to_send;
  
  public:

     g1_help_screen_class(w16 w, w16 h, 
                       i4_graphical_style_class *style, 
                       const i4_const_str &image_name,
                       w32 mess_id_to_send);
     ~g1_help_screen_class();
          
     char *name() { return "help screen"; } 
     virtual void parent_draw(i4_draw_context_class &context);
     void receive_event(i4_event *ev);
     
};

#endif


