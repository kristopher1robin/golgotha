/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

#ifndef G1_DRAW_CONTEXT_HH
#define G1_DRAW_CONTEXT_HH

#include "arch.hh"
#include "math/vector.hh"

class r1_render_api_class;
class i4_transform_class;
class i4_image_class;
class i4_draw_context_class;
class i4_graphical_style_class;
class i4_window_class;
class i4_window_manager_class;
class g1_light_set;
class r1_render_api_class;


class g1_draw_context_class
{
  enum { TRANS_STACK_SIZE=8 };
  i4_transform_class *stack[TRANS_STACK_SIZE];
  int top;

public:  
  void push(i4_transform_class &t) { stack[top++]=transform; transform=&t; }
  void pop() { top--; transform=stack[top]; }

  i4_bool draw_editor_stuff;

  i4_transform_class *transform;


  i4_image_class *screen;
  i4_draw_context_class *context;
  i4_graphical_style_class *style;
  g1_light_set *light;
  w32 default_render_bits;       // see polylist.hh, controls wireframe, texture, light rendering

  // this should be how much to scale the camera to fit window (maximum dimension of window)
  // for a pixel aspect ration of 1-1 window_scale_x==window_scale_y
  i4_float camera_scale_x;  
  i4_float camera_scale_y;

  i4_float texture_scale;          // if you scale a model beyond normal size, change this

  g1_draw_context_class();
  
  void window_setup(w32 win_x, w32 win_y, w32 win_w, w32 win_h,
                    float &center_x, float &center_y,
                    float &scale_x, float &scale_y,
                    float &ooscale_x, float &ooscale_y);
} ;

#endif
