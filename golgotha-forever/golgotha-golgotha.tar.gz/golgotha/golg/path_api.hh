/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

#error

#ifndef PATH_API_HH
#define PATH_API_HH

#include "error/error.hh"
#include "memory/malloc.hh"
#include "math/num_type.hh"
#include <string.h>

enum g1_compass_direction { G1_NORTH=1, G1_SOUTH=2, G1_WEST=4, G1_EAST=8 };

class g1_block_map_class
{
protected:
  w8 *block_map;
  w16 wx,wy;
  w16 bwx;

  int max_fit_NS(int x, int y, g1_compass_direction dir, int max) const;
  int max_fit_WE(int x, int y, g1_compass_direction dir, int max) const;

public:
  w16 width() const { return wx; }
  w16 height() const { return wy; }

  g1_block_map_class() : block_map(0) {}
  g1_block_map_class(w16 _wx, w16 _wy) { init(_wy,_wy); }

  void init(w16 _wx, w16 _wy)
  {
    wx = _wx; wy = _wy;
    bwx = (wx+1)/2;
    block_map = (w8 *)i4_malloc(bwx*wy, "block_map");
    I4_ASSERT(block_map, "No block map allocated");
  }

  void uninit()
  {
    if (block_map)
      i4_free(block_map);
    block_map=0;
  }

  ~g1_block_map_class()
  {
    uninit();
  }

  void clear()
  {
    memset(block_map, 0, bwx*wy);
  }

  void block(w16 x, w16 y, w8 dir)
  {
    if (x&1)
      dir <<= 4;
    x /= 2;
    block_map[y*bwx+x] |= dir;
  }

  void unblock(w16 x, w16 y, w8 dir)
  {
    if (x&1)
      dir <<= 4;
    x /= 2;
    block_map[y*bwx+x] &= ~(dir);
  }

  i4_bool is_blocked(w16 x, w16 y, w8 dir) const
  {
    if (x&1)
      dir <<= 4;
    x /= 2;
    return (block_map[y*bwx+x] & dir)!=0;
  }

  i4_float line_of_sight(i4_float x1, i4_float y1, i4_float x2, i4_float y2,
                         i4_float rad_x=5.0, i4_float rad_y=5.0) const;
};

#endif

