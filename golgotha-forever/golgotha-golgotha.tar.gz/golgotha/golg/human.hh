/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

#ifndef HUMAN_HH
#define HUMAN_HH

#include "team_api.hh"
#include "memory/que.hh"

class g1_human_class : public g1_team_api_class
{
public:
  enum { MAX_COMMANDS = 30 };

  g1_human_class(g1_loader_class *f);
  ~g1_human_class();

  i4_float mouse_look_increment_x, mouse_look_increment_y;

  g1_typed_reference_class<g1_object_class> selected_object;
  g1_typed_reference_class<g1_object_class> preassigned[10];

  void send_selected_units(i4_float x, i4_float y);
  void clicked_on_object(g1_object_class *o);

  w8 determine_cursor(g1_object_class *object_mouse_is_on);
  void player_clicked(g1_object_class *o, float gx=0, float gy=0);
  int build_unit(g1_object_type type);

  virtual void think();
  virtual char *name() { return "Human"; }

  virtual void load(g1_loader_class *fp);
};

extern g1_human_class *g1_human;

#endif
