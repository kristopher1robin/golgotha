/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

#include "map.hh"
#include "visible.hh"
#include "solvemap_astar.hh"

i4_bool g1_map_class::find_path(i4_float start_x, i4_float start_y,
                                i4_float destx, i4_float desty,
                                i4_float *points, w16 &t_nodes)
{
  if (destx<0) destx=0; else if (destx>=w) destx = w-1;
  if (desty<0) desty=0; else if (desty>=h) desty = h-1;

  // jc: fixme
  //  i4_float tt=get_block_map(grade)->line_of_sight(c->x,c->y,destx,desty, rad_x, rad_y);
  //  i4_float tc=c->calculate_size(destx - c->x,desty - c->y)-0.001;
  if (0) //tt>=tc)
  {
    // if the destination is visible, then path is just a line
    points[0]=destx;
    points[1]=desty;
    //    points[2]=c->x;
    //    points[3]=c->y;
    t_nodes=2;
  }
  else
  {
    if (!solver->path_solve(start_x, start_y,
                            destx, desty,
                            points, t_nodes))
    {
      t_nodes=0;
      return i4_F;
    }
  }
  return i4_T;
}
