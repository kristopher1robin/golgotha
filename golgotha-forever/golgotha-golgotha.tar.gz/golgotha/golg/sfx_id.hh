/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

// Automatically generated file.  DO NOT EDIT.
// To update run the 'enumer' program

#ifndef __sfx_id_hh__
#define __sfx_id_hh__

enum
{
  g1_sfx_misc_purchase_button_click,
  g1_sfx_misc_production_pad_click,
  g1_sfx_select_m01,
  g1_sfx_select_m02,
  g1_sfx_select_m03,
  g1_sfx_select_m04,
  g1_sfx_select_f01,
  g1_sfx_select_f02,
  g1_sfx_select_f03,
  g1_sfx_select_f04,
  g1_sfx_deploy_m01,
  g1_sfx_deploy_m02,
  g1_sfx_deploy_m03,
  g1_sfx_deploy_f01,
  g1_sfx_deploy_f02,
  g1_sfx_deploy_f03,
  g1_sfx_misc_ricochet_1,
  g1_sfx_explosion_generic,
  g1_sfx_explosion_ground_vehicle,
  g1_sfx_explosion_super_mortar,
  g1_sfx_misc_turbine1,
  g1_sfx_assembled_jet,
  g1_sfx_rumble_jet,
  g1_sfx_assembled_kamikaze_trike,
  g1_sfx_assembled_engineering_vehicle,
  g1_sfx_rumble_engineering_vehicle,
  g1_sfx_assembled_helicopter,
  g1_sfx_rumble_helicopter,
  g1_sfx_assembled_peon_tank,
  g1_sfx_rumble_peon_tank,
  g1_sfx_fire_peon_tank,
  g1_sfx_assembled_missile_truck,
  g1_sfx_rumble_missile_truck,
  g1_sfx_fire_missile_truck,
  g1_sfx_misc_missile_truck_lower,
  g1_sfx_misc_missile_truck_raise,
  g1_sfx_assembled_electric_car,
  g1_sfx_rumble_electric_car,
  g1_sfx_misc_electric_car_charged,
  g1_sfx_fire_supergun,
  g1_sfx_rumble_supertank,
  g1_sfx_misc_supertank_refuel,
  g1_sfx_misc_supertank_main_gun_refuel,
  g1_sfx_misc_supertank_chain_gun_refuel,
  g1_sfx_misc_supertank_missile_refuel,
  g1_sfx_fire_supertank_main1,
  g1_sfx_fire_supertank_auto1,
  g1_sfx_fire_supertank_auto2,
  g1_sfx_fire_supertank_auto3,
  g1_sfx_misc_supertank_main_gun_charge,
  g1_sfx_last};

#endif
