/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

#ifndef G1_LIGHT_HH
#define G1_LIGHT_HH

#include "math/vector.hh"

class i4_saver_class;
class i4_loader_class;

struct g1_light_info
{
  float directional_intensity;           // 0..1
  i4_3d_vector direction;

  float ambient_intensity;               // 0..1
  float shadow_intensity[256];

  void recalc_shadow_intensity();
  void set_ambient_intensity(float v);
  void set_directional_intensity(float v);

  void save(i4_saver_class *fp);
  i4_bool load(i4_loader_class *fp);
  void defaults();
  g1_light_info();
} ;

extern g1_light_info g1_lights;




#endif

