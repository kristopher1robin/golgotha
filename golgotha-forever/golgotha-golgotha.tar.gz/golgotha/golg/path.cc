/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

#include "path.hh"
#include "memory/malloc.hh"
#include "g1_limits.hh"
#include "saver_id.hh"
#include "saver.hh"
#include <string.h>

g1_path_manager_class g1_path_manager;

enum {PATH_VERSION=1};

class g1_path_class
{
public:
  class point
  {
  public:
    i4_float x,y;
  } *node;
  w8 nodes;
  w8 current;

  i4_bool get_pos(int n, i4_float &x, i4_float &y) const
  {
    int i=current+n;

    if (i<0 || i>=nodes)
      return i4_F;

    x = node[i].x;
    y = node[i].y;
    return i4_T;
  }
  i4_float x() const { return node[current].x; }
  i4_float y() const { return node[current].y; }

  i4_bool last() const { return current == nodes-1; }

  void alloc()
  {
    if (nodes>0)
      node = (point *)i4_malloc(sizeof(point)*(nodes), "alloc_path");
    else
      node = 0;
  }

  g1_path_class(w32 t_positions, i4_float *positions)
  {
    nodes = t_positions;
    current = 0;
    alloc();
    for (w32 i=0; i<nodes; i++)
    {
      //find_path returns paths in reverse order. this will fix that
      node[nodes-1-i].x = *positions++;
      node[nodes-1-i].y = *positions++;
    }
  }

  g1_path_class(g1_loader_class *fp)
  {
    if (fp && fp->check_version(PATH_VERSION))
    {
      nodes = fp->read_8();
      current = fp->read_8();
      alloc();
      for (w8 i=0; i<nodes; i++)
      {
        node[i].x = fp->read_float();
        node[i].y = fp->read_float();
      }

      fp->end_version(I4_LF);
    }
    else
    {
      nodes = 0;
      current = 0;
    }
  }

  void save(g1_saver_class *fp)
  {
    fp->start_version(PATH_VERSION);
    fp->write_8(nodes);
    fp->write_8(current);
    for (w8 i=0; i<nodes; i++)
    {
      fp->write_float(node[i].x);
      fp->write_float(node[i].y);
    }
    fp->end_version();
  }

  ~g1_path_class()
  {
    if (node)
      delete node;
  }

  void advance_path()
  {
    current++;
  }
};

g1_path_handle g1_path_manager_class::alloc_path(w32 t_positions,
                                                 i4_float *positions)
{
  return new g1_path_class(t_positions,positions);
}

void g1_path_manager_class::get_position(g1_path_handle path, i4_float &x, i4_float &y)
{
  x=path->x();
  y=path->y();
}

i4_bool g1_path_manager_class::get_nth_position(g1_path_handle path, int n, 
                                                i4_float &x, i4_float &y)
{
  if (!path)
    return i4_F;
  return path->get_pos(n,x,y);
}

g1_path_handle g1_path_manager_class::advance_path(g1_path_handle path)
{
  if (path->last())
  {
    delete path;
    return 0;
  }

  path->advance_path();
  return path;
}


i4_bool g1_path_manager_class::is_last_path_point(g1_path_handle path)
{
  return path->last();
} 

void g1_path_manager_class::free_path(g1_path_handle &path)
{
  delete path;
}

void g1_path_manager_class::save(g1_saver_class *fp, g1_path_handle path)
{
  path->save(fp);
}

g1_path_handle g1_path_manager_class::load(g1_loader_class *fp)
{
  return new g1_path_class(fp);
}
