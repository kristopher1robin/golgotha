/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

#ifndef G1_SERVER_HH
#define G1_SERVER_HH


#include "network/net_addr.hh"
#include "network/net_sock.hh"
#include "g1_limits.hh"
#include "time/time.hh"

class g1_server_class
{
  friend class g1_server_start_window;

  struct client
  {
    i4_net_address *addr;
    i4_time_class last_data;
    i4_str *username;
    i4_net_socket *send;
    
    void cleanup();
  };

  client clients[G1_MAX_PLAYERS];   // network address of each client

  i4_net_socket *udp_port;
  enum {
    WAITING_FOR_PLAYERS,
    RUNNING,
    QUITING
  } state;
    
  i4_net_protocol *protocol;
  void send_player_joined(int client_num);
  void process_client_packet(w8 *packet, int packet_length, int client_num);
  i4_str *map_name;
  i4_bool list_changed;

public:
  g1_server_class(int use_port, i4_net_protocol *protocol);
  void start_game();
  void poll();  
  ~g1_server_class();
};

extern class g1_server_class *g1_server;

#endif
