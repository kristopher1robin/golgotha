/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

#ifndef G1_NET_STARTUP_HH
#define G1_NET_STARTUP_HH


#include "window/window.hh"
#include "time/timedev.hh"
#include "g1_limits.hh"

class i4_text_input_class;
class i4_graphical_style_class;
class i4_event;
class i4_event_handler_class;
class i4_finder_socket;
class i4_notifier_socket;
class i4_button_class;
class i4_event_reaction_class;
class i4_net_protocol;

class g1_net_window_class : public i4_parent_window_class
{
protected:
  i4_image_class *bg;
  i4_time_device_class::id poll_event_id;
  i4_graphical_style_class *style;
  i4_net_protocol *protocol;
  int poll_delay, poll_id;

  i4_event_reaction_class *create_orec(int mess_id);
public:
  virtual void object_message(int id) { ; }
  virtual void poll() { ; }

  g1_net_window_class(w16 w, w16 h, 
                      i4_graphical_style_class *style,
                      i4_net_protocol *protocol,
                      char *bg_res,
                      int poll_delay, int poll_event_id);
    
  virtual void receive_event(i4_event *ev);
  virtual void parent_draw(i4_draw_context_class &context);

  virtual ~g1_net_window_class();
};

class g1_startup_window : public g1_net_window_class
{
  i4_button_class **buts;
  int t_buts;
  i4_text_input_class *hostname, *username;
  i4_finder_socket *find;

  enum { START_SERVER, QUIT_NET_GAME, POLL, LAST };

  void free_buts();
  void grab_uname();
public:
  virtual void object_message(int id);
  virtual void poll();

  g1_startup_window(w16 w, w16 h, 
                    i4_graphical_style_class *style,
                    i4_net_protocol *protocol);

  char *name() { return "net_startup"; }
  ~g1_startup_window();
};

class g1_server_start_window : public g1_net_window_class
{
  i4_notifier_socket *note;
  i4_window_class *names[G1_MAX_PLAYERS];

  enum { START_NET_GAME, QUIT_NET_GAME, POLL };
public:
  g1_server_start_window(w16 w, w16 h, 
                         i4_graphical_style_class *style,
                         i4_net_protocol *protocol);

  virtual void object_message(int id);
  virtual void poll();

  char *name() { return "server_menu"; }
  ~g1_server_start_window();
};


class g1_client_wait_window : public g1_net_window_class
{
  enum { QUIT_NET_GAME, POLL };

public:
  g1_client_wait_window(w16 w, w16 h, 
                         i4_graphical_style_class *style,
                         i4_net_protocol *protocol);

  virtual void object_message(int id);
  virtual void poll();

  char *name() { return "client_wait"; }
  ~g1_client_wait_window();
};


#endif


