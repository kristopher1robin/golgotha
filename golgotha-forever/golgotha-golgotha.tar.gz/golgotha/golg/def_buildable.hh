/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

#ifndef G1_DEF_BUILDABLE_HH
#define G1_DEF_BUILDABLE_HH

#include "g1_object.hh"
#include "objs/defaults.hh"
//#include "objs/factory.hh"

class g1_factory_class;

template <class T>
class g1_buildable_object_definer : public g1_object_definition_class
{
public:
  g1_object_defaults_struct *defaults;
  g1_object_build_info      build_info;
  
  g1_buildable_object_definer<T>
  (char *name,
   char *factory_name,
   w32 type_flags,
   function_type _init = 0,
   function_type _uninit = 0)
    : g1_object_definition_class(name, type_flags, _init, _uninit)
  { 
    build_info.factory_name = factory_name;
  }

  virtual g1_object_class *create_object(g1_object_type id,
                                         g1_loader_class *fp)
  {
    T *o=new T(id, fp);
    o->defaults=defaults;
    o->init();
    return o;
  }

  virtual void init()
  {
    defaults=g1_get_object_defaults(_name);
    build_info.cost=defaults->cost;

    g1_object_definition_class::init();
  }
  g1_object_build_info *get_build_info() { return &build_info; }
};

#ifndef G1_SELECTABLE_ENUM
enum { UNSELECTABLE = i4_F, SELECTABLE = i4_T };
#endif

#endif
