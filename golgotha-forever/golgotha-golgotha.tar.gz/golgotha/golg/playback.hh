/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

#ifndef PLAYBACK_HH
#define PLAYBACK_HH

enum
{
  G1_COMMAND_END=0,
  G1_COMMAND_TURN,
  G1_COMMAND_ACCEL,
  G1_COMMAND_STRAFE,
  G1_COMMAND_ZOOM,
  G1_COMMAND_LOOK,
  G1_COMMAND_DEPLOY,
  G1_COMMAND_BUILD,
  G1_COMMAND_TARGET,
  G1_COMMAND_FIRE0,
  G1_COMMAND_FIRE1,
  G1_COMMAND_FIRE2,
  G1_COMMAND_CONTINUE,
  G1_NUM_COMMANDS
};

#endif
