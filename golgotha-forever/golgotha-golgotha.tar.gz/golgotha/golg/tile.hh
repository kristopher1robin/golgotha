/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

#ifndef TILE_HH
#define TILE_HH

#include "init/init.hh"
#include "tex_id.hh"

class i4_const_str;
class g1_object_class;
class g1_quad_object_class;
class r1_render_api_class;
class g1_map_class;
class li_object;
class li_environment;
class g1_map_cell_class;

class g1_tile_class
{
public:
  r1_texture_handle texture;
  w32 filename_checksum;           // used to identify matchup tiles with saved levels
  w8 flags;
  w16 selection_order;

  enum { 
    SELECTABLE        =1,     // if user can pick it for tile selection
    WAVE              =2,     // water-wave
    BLOCKING          =4      // blocks vehicle entry
  };

  float damping_fraction, damping_e, friction_fraction;
  sw16 damage;

  void init();    // initializes default values for the tile

  void set_friction(float uB);
  
  void get_properties(li_object *properties, li_environment *env);

  void apply_to_cell(g1_map_cell_class &cell);
} ;



class g1_tile_man_class : public i4_init_class
{
  g1_tile_class *array;
  int t_tiles, max_tiles;
  int sorted_by_checksum;
  r1_texture_handle pink, default_tile_type;

  

public:  
  int get_tile_from_name(i4_const_str &name);
  int get_tile_from_name(char *name);
  int get_tile_from_checksum(w32 checksum);

  g1_tile_man_class();

  void uninit();

  void reset(int _max_tiles);
  void add(li_object *o, li_environment *env);
  void get_tile_texture(li_object *o, li_object *&texture_name, li_object *&save_name);


  g1_tile_class *get(w32 handle) { return array+handle; }
  r1_texture_handle get_texture(w32 handle) { return array[handle].texture; }

  r1_texture_handle get_pink() { return pink; }
  int get_default_tile_type() { return default_tile_type; }

  
  void finished_load();
  int remap_size();
  int get_remap(int tile_num);
  
  w32 total() { return t_tiles; }
};


extern g1_tile_man_class g1_tile_man;


#endif

