/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

//{{{ 3D File Loader
//
//  Not final version
//
//$Id: load3d.hh,v 1.1.1.1 2001/11/02 19:51:11 rodal Exp $

#ifndef G1_LOAD3D_HH
#define G1_LOAD3D_HH

#include "memory/growheap.hh"
#include "string/string.hh"
#include "math/vector.hh"
#include "obj3d.hh"

class r1_texture_manager_class;
class r1_render_api_class;

class g1_quad_object_loader_class : public g1_base_object_loader_class
{
protected:
  g1_quad_object_loader_class() : heap(0) {}
public:
  i4_grow_heap_class *heap;
  r1_texture_manager_class *tman;
  const i4_const_str *error_name;

  g1_quad_object_loader_class(i4_grow_heap_class *_heap) : heap(_heap) {}

  virtual g1_quad_object_class *allocate_object();

  virtual void set_num_vertex(w16 num_vertex);

  virtual void set_num_animations(w16 anims);
  virtual void create_animation(w16 anim, const i4_const_str &name, w16 frames);

  virtual void create_vertex(w16 anim, w16 frame, w16 index, const i4_3d_vector& v);
  virtual void store_vertex_normal(w16 anim, w16 frame, w16 index, const i4_3d_vector& normal);

  virtual void set_num_quads(w16 num_quads);
  virtual void create_quad(w16 quad, int verts, w16 *ref, w32 flags);
  virtual void store_texture_name(w32 quad, const i4_const_str &name);
  virtual void store_texture_params(w32 quad, i4_float scale, i4_float *u, i4_float *v);
  virtual void store_quad_normal(w16 quad, const i4_3d_vector& v);

  virtual void set_num_mount_points(w16 num_mounts);
  virtual void create_mount_point(w32 index, const i4_const_str &name, const i4_3d_vector &off);

  virtual void set_num_texture_animations(w16 num_textures);
  virtual void create_texture_animation(w32 index, w16 quad, w8 max_frames, w8 frames_x,
                                        i4_float du, i4_float dv, i4_float speed);
  virtual void create_texture_pan(w32 index, w16 quad,
                                  i4_float du, i4_float dv, i4_float speed);

  virtual void finish_object();

  g1_quad_object_class *load(i4_loader_class *fp, const i4_const_str &_error_name,
                             r1_texture_manager_class *_tman);
};

#endif
