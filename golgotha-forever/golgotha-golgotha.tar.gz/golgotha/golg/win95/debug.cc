/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

#include <windows.h>
#include <process.h>
#include <stdio.h>

class debug_start
{
public:
  debug_start() 
  {
    PROCESS_INFORMATION piProcInfo; 
    STARTUPINFO siStartInfo; 
    
    /* Set up members of STARTUPINFO structure. */ 
    
    siStartInfo.cb = sizeof(STARTUPINFO); 
    siStartInfo.lpReserved = NULL; 
    siStartInfo.lpReserved2 = NULL; 
    siStartInfo.cbReserved2 = 0; 
    siStartInfo.lpDesktop = NULL; 
    siStartInfo.dwFlags = 0; 
    
  /* Create the child process. */ 
  
    char cmd[200];
    sprintf(cmd,"f:\\jc\\code\\w95_db\\dbug\\debug\\dbug.exe %d", _getpid());
    CreateProcess(NULL, 
                  cmd,
                  NULL,          /* process security attributes        */ 
                  NULL,          /* primary thread security attributes */ 
                  TRUE,          /* handles are inherited              */ 
                  0,             /* creation flags                     */ 
                  NULL,          /* use parent's environment           */ 
                  NULL,          /* use parent's current directory     */ 
                  &siStartInfo,  /* STARTUPINFO pointer                */ 
                  &piProcInfo);  /* receives PROCESS_INFORMATION       */ 
    Sleep(5000);
  }
} debug_start_instance;
