/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

#include "draw_context.hh"
#include "g1_render.hh"

g1_draw_context_class::g1_draw_context_class()
{ 
  style=0;
  context=0;
  screen=0;
  transform=0;

  texture_scale=1;
  top=0;
  light=0;
  draw_editor_stuff=i4_F;

  default_render_bits=0;

}


void g1_draw_context_class::window_setup(w32 win_x, w32 win_y, w32 win_w, w32 win_h,
                                         float &center_x, float &center_y,
                                         float &scale_x, float &scale_y,
                                         float &ooscale_x, float &ooscale_y)
{
  w32 max_dim=win_w > win_h ? win_w : win_h;
    
  camera_scale_x=max_dim;
  camera_scale_y=max_dim;

  center_x=win_x + (i4_float)win_w/2.0;
  center_y=win_y + (i4_float)win_h/2.0;

  scale_x = (float)max_dim/win_w;
  scale_y = (float)max_dim/win_h;

  ooscale_x = (float)win_w/(float)max_dim;
  ooscale_y = (float)win_h/(float)max_dim;
}
