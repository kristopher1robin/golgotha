/********************************************************************** 

    Golgotha Forever - A portable, free 3D strategy and FPS game.
    Copyright (C) 1999 Golgotha Forever Developers

    Sources contained in this distribution were derived from
    Crack Dot Com's public release of Golgotha which can be
    found here:  http://www.crack.com

    All changes and new works are licensed under the GPL:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    For the full license, see COPYING.

***********************************************************************/
 

#ifndef G1_MUSIC_HH
#define G1_MUSIC_HH

#include "arch.hh"
class i4_stream_wav_player;

class g1_music_manager_class
{
  i4_bool no_songs;
  sw32 song_on;
  sw32 total_songs;
  sw32 total_missing;
  i4_stream_wav_player *stream;
  i4_bool playing;

  void next_song();

public: 
  void init();
  void uninit();

  void poll();  // called by main game once per game loop

  void start(); 
  void stop();
};

extern g1_music_manager_class g1_music_man;


#endif
